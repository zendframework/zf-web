<?php

class BbahhService
{
	/**
	 * Returns hello world.
	 *
	 * @return string
	 */	
	public function printHelloWorld()
	{
		return 'hello world';
	}
	
	/**
	 * Returns the object that was passed in.
	 *
	 * @param object $object
	 * @return object
	 */
	public function returnIt($object)
	{
		$writer = new Zend_Log_Writer_Stream(APPLICATION_PATH . '../../logs/info.log');
		$logger = new Zend_Log($writer);
		$logger->info('returnIt '. get_class($object) );
		
		return $object;
	}	
	
	public function getAC()
	{
		return new ArrayCollection();
	}
	
	/**
	 * Returns the object class name.
	 *
	 * @param Object $object
	 * @return string
	 */	
	public function getType($object)
	{
		return gettype($object);
	}
}