<?php
class ArrayCollection{
	//public $_explicitType = "mx.collections.ArrayCollection";
	var $_explicitType = "flex.messaging.io.ArrayCollection";
	
	var $source = array();
 
	function ArrayCollection()
	{
		$this->source = array();
	}
}

?>