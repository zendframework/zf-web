<?php
class Model_DbTable_AwesomeGames extends Zend_Db_Table
{

    protected $_name = 'awesomegames';
    


}