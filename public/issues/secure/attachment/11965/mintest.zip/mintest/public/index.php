<?php
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 1);
defined('APPLICATION_PATH')
    || define('APPLICATION_PATH', realpath(dirname(__FILE__) . '/../application'));

defined('APPLICATION_ENV')
    || define('APPLICATION_ENV', (getenv('APPLICATION_ENV') ? getenv('APPLICATION_ENV') : 'production'));

set_include_path(implode(PATH_SEPARATOR, array(
    dirname(__FILE__) . '/../library',
    get_include_path(),
)));

require_once 'Zend/Application.php';

$application = new Zend_Application(
    APPLICATION_ENV,
    array(
        'config' => APPLICATION_PATH . '/configs/application.ini',
        'resources' => array(
            'Layout' => array(
                'viewSuffix' => 'tpl'
            )
        )
    )
);

echo '<pre>' . print_r($application->getOptions(), true) . '</pre>';

//$application->bootstrap()->run(); // this is the "run" line
