<?php

class SimpleCaptchaForm extends Zend_Form 
{
    
    
    public function init()
    {
        
        $captchaImage = new Zend_Captcha_Image();
        $captchaImage->setFont(Standart_Main::getDirs('fonts', 'arial.ttf'));
        $captchaImage->setFontSize(30);
        $captchaImage->setWordlen(6);
        $captchaImage->setImgDir(Standart_Main::getDirs('wwwStatic', array('images', 'captcha')));
        $captchaImage->setImgUrl(Zend_Registry::get('config')->host->static.'/images/captcha/');
        $captchaImage->setWidth(175);
        $captchaImage->setHeight(75);
        $captchaImage->setName('captcha');
        $captchaImage->getSession()->setExpirationHops(10);
        
        $elementCaptcha = new Zend_Form_Element_Captcha(
            'captcha',
            array(
                'captcha' => $captchaImage
            )
        );
        
        $elementDoSubmit = new Zend_Form_Element_Submit('doSubmit');
        
        $this->addElements(array($elementCaptcha, $elementDoSubmit));
        
    }
    
}