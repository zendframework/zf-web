<?php

class Test_CaptchaController extends Zend_Controller_Action
{

    public function indexAction()
    {
        $form = new SimpleCaptchaForm();
        
        $this->view->formIsValid = null;
        
        if (Standart_Main::buttonPressed('doSubmit')) {
            if ($form->isValid($_POST)) {
                $this->view->formIsValid = true;
            } else {
                $this->view->formIsValid = false;
            }
        }
        
        $this->view->form = $form;
    }
    
}