<?php

class AdEditForm extends Zend_Form 
{
    public function init()
    {
        $subForm = New Zend_Form_SubForm();
        $subForm->setLegend('adsFields');
       
        $captchaImage = new Zend_Captcha_Image();
        $captchaImage->setFont('/usr/share/fonts/truetype/freefont/FreeSansBold.ttf');
        $captchaImage->setFontSize(30);
        $captchaImage->setWordlen(6);
        $captchaImage->setImgDir('/home/web/zf/public/img/captcha');
        $captchaImage->setImgUrl('/img/captcha/');
        $captchaImage->setWidth(175);
        $captchaImage->setHeight(75);
        $captchaImage->setName('captcha');
        
        $elementCaptcha = new Zend_Form_Element_Captcha(
            'captcha',
            array(
                'captcha' => $captchaImage
            )
        );
        
        $elementDoSave = new Zend_Form_Element_Submit('doSave');
        
        $subForm->addElements(array(
            $elementCaptcha
        ));
        
        
        $this->addSubForm($subForm, 'ads');
        $this->addElement($elementDoSave);
    }
}
