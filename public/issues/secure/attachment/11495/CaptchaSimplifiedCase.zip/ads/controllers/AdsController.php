<?php

class AdsController extends Zend_Controller_Action 
{
    public function editAction()
    {
        $request = $this->getRequest();
        $form = new AdEditForm();
       
        $this->view->isValid = false;
        if ($request->isPost()) {
            $form->populate($request->getPost());
            if ($form->doSave->isChecked()) {
                if ($form->isValid($request->getPost())) {
                    $this->view->isValid = true;
                }
            }
        }
        
        $this->view->form = $form;
    }
}
