<?php
require_once 'Zend/Loader/Autoloader.php';

class ZF10024test extends PHPUnit_Framework_TestCase
{
    protected $_testFile;
    
    public function setUp()
    {
        $this->_testFile = __DIR__ . '/Foo-Bar.php';
    }
    
    protected function assertPreConditions()
    {
        $this->assertFileExists($this->_testFile,"$this->_testFile is a
            required file for the test to run, could not find it");
        $this->assertRegExp('#class Foo_Bar#', file_get_contents($this->_testFile), "$this->_testFile should
        containt a class Foo_Bar for the test to run");
    }
    
    public function testZF10024()
    {
        $autoload = Zend_Loader_Autoloader::getInstance();
        $autoload->pushAutoloader(function ($class)
            {
            require str_replace('_','-',$class) . '.php';
            });
        new Foo_Bar;
    }
}