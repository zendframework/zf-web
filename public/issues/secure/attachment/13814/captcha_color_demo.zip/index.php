<body bgcolor="#000000">
<?php
$myLittleColorsFarm = array(
	array(array(0, 0, 0), array(255, 255, 255)),
	array(array(255, 0, 0), array(255, 255, 255)),
	array(array(0, 255, 0), array(255, 255, 255)),
	array(array(0, 0, 255), array(255, 255, 255)),
	array(array(0, 0, 0), array(255, 0, 0)),
	array(array(0, 0, 0), array(0, 255, 0)),
	array(array(0, 0, 0), array(0, 0, 255)),
	array(array(255, 0, 255), array(0, 255, 255)),
	array(array(229, 223, 46), array(84, 84, 159))
);

include "Captcha/Image.php";

$image = new Zend_Captcha_Image();
$image->setFont("./Verdana.ttf");
$image->setImgUrl("/captcha/img/");
$image->setImgDir("./img/");
$image->setHeight(150);
$image->setWidth(400);
$image->setFontSize(36);

foreach ($myLittleColorsFarm as $colors) {
	$image->setFontColor($colors[0]);
	$image->setBackgroundColor($colors[1]);
	$image->generate();

	echo $image->render()." ";
}
?>
</body>