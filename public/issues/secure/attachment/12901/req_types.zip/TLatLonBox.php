<?php
final class fgSDK_Types_TLatLonBox extends fgSDK_Types_TBase{
    public $North = null;
    public $South = null;
    public $East = null;
    public $West = null;
}

