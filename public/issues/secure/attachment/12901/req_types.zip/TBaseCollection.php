<?php
abstract class fgSDK_Types_TBaseCollection implements Iterator, ArrayAccess {
    protected $_stack = array();

    abstract function Add($obj);
    abstract function Contains();
    
    public function Remove($index){
        if(isset($this->_stack[$index]))
            unset($this->_stack[$index]);
    }
    

    public function Clear(){
        unset($this->_stack);
        $this->_stack = array();
    }
    
    public function rewind() {
        reset($this->_stack);
    }

    public function current() {
        return current($this->_stack);
    }

    public function key() {
        return key($this->_stack);
    }

    public function next() {
        return next($this->_stack);
    }

    public function valid() {
        return $this->current() !== false;
    } 
    
    public function offsetExists($offset) {
        return array_key_exists($this->_stack, $offset);
    }
 
    public function offsetGet($offset) {
        return $this->_stack[$offset];
    }
 
    public function offsetSet($offset, $value) {
        if (is_null($offset)) {
          $this->_stack[] = $value;
        } else {
          $this->_stack[$offset] = $value;
        }
    }
 
    public function offsetUnset($offset) {
        unset($this->_stack[$offset]);
    }
}