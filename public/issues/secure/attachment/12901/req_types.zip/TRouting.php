<?php
class fgSDK_Types_TRouting extends fgSDK_Types_TBase{
    /**
    * Place
    * 
    * @var fgSDK_Types_TPlace
    */
    public $Origin;
    /**
    * Destination
    * 
    * @var fgSDK_Types_TPlace
    */
    public $Destination;
    public $RoutingIndex = -1;
    
    public function __construct(fgSDK_Types_TPlace $origin, fgSDK_Types_TPlace $destination, $loadFromArray = null){
        parent::__construct($loadFromArray);
        $this->Origin = $origin;
        $this->Destination = $destination;
    }
}