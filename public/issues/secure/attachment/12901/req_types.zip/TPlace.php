<?php
class fgSDK_Types_TPlace extends fgSDK_Types_TBase {
    public $Address = null;
    public $Accuracy = null;
    public $CountryCode = null;
    public $CountryName = null;
    public $Longitude = null;
    public $Latitude = null;
    public $PostalCode = null;
    public $Placetype = fgSDK::PLACE_TYPE_GEO;
    /** 
    * LatLonBox
    * 
    * @var fgSDK_Types_TLatLonBox
    */
    public $LatLonBox = null;
    
    public function __construct($loadFromArray = null){
        parent::__construct($loadFromArray);
        $this->LatLonBox = new fgSDK_Types_TLatLonBox();
    }
}

