<?php
abstract class fgSDK_Types_TBase{
    
    public function __construct($loadFromArray=null){
        foreach($this as $key => $value){
            if(isset($loadFromArray[$key]))
                $this->{$key} = $loadFromArray[$key];
        }
    }
}