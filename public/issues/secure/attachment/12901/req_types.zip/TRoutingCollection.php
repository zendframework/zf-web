<?php
class fgSDK_Types_TRoutingCollection extends fgSDK_Types_TBaseCollection{
    
    public function __construct(){
                
    }
    
    /**
    * put your comment there...
    * 
    * @param fgSDK_Types_TRouting  $obj
    */
    public function Add($obj){
        if(!$obj instanceof fgSDK_Types_TRouting)
            throw new Exception('obj must be a instance of fgSDK_Types_TRouting');
        $this[] = $obj;
    }
    
    public function Contains(){
        throw new Exception('Not implemented');
        
    }

}
