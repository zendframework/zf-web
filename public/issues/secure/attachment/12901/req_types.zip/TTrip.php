<?php
class fgSDK_Types_TTrip extends fgSDK_Types_TBase{
    public $TripID = null;
    public $IDuser = null;
    public $Startdate = null;
    public $Starttime = null;
    public $Smoker = fgSDK::TRIP_SMOKER_NO;
    public $Prefgender = null;
    public $NumberPlate = null;
    public $Places = null;
    public $Enterdate = null;
    public $Contactlandline = null;
    public $Contactmobile = null;
    public $Description = null;
    public $ClientIP = null;
    public $Triptype = fgSDK::TRIP_TYPE_OFFER;
    /**
    * Routing
    *
    * @var fgSDK_Types_TRoutingCollection
    */
    public $Routings;
    /**
    * All Reoccurs
    *
    * Default is null
    * @var fgTripReoccurObject
    */
    public $Reoccurs = null;

    public function __construct($loadFromArray=null){
        parent::__construct($loadFromArray);
        $this->Routings = new fgSDK_Types_TRoutingCollection();
    }
    
    public function IsReoccuring(){
        return !is_null($this->Reoccurs);
    }
    
}