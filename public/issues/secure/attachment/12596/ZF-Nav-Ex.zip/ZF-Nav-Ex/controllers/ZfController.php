<?php
class ZfController extends Zend_Controller_Action
{
    public function init()
    {
        $config = new Zend_Config_Xml('../application/configs/example.xml');

        $this->view->navigation(new Zend_Navigation($config->toArray()));
    }

    public function indexAction()
    {

    }

    public function navigationAction()
    {

    }

    public function viewAction()
    {

    }

    public function viewhelperAction()
    {

    }

    public function viewhelpernavigationAction()
    {

    }
}
?>