<?php
class TestController extends Zend_Controller_Action
{
    public function init()
    {
        $config = new Zend_Config_Xml('../application/configs/example.xml');

        $this->view->navigation(new Zend_Navigation($config->toArray()));
    }

    public function indexAction()
    {
    }
}
?>