<?php
// now we will find all classes, because ZendFramework and PEAR are in include-path
require_once "Zend/Loader.php";
Zend_Loader::registerAutoload();

echo "\n".showMemory('start MDB2');
$config = new Zend_Config_Ini('../../application/config/config.ini', 'production');
$bdb1 = MDB2::factory('mssql://' . $config->db->config->username . ':' . $config->db->config->password . '@' . $config->db->config->host . '/' . $config->db->config->dbname);
runLoopMDB2($bdb1);
unset($bdb1);
// =============================================

echo "\n\n\n".showMemory('start PDO_SQLITE');
$params = array ('dbname' => ':memory:');
$bdb2 = Zend_Db::factory('PDO_SQLITE', $params);

$bdb2->query("CREATE TABLE Server (ServerID, Value)");
$bdb2->query("INSERT INTO Server (ServerID, Value) VALUES (1,34)");
runLoop($bdb2);
unset($bdb2);
// =============================================

echo "\n\n\n".showMemory('start PDO_MSSQL');
$bdb3 = Zend_Db::factory($config->db->adapter, $config->db->config->toArray());
runLoop($bdb3);
unset($bdb3);
// =============================================


function runLoopMDB2($bdb) {
	echo "\n".showMemory('after1');
	$res = array();
	for ($i=0;$i<1000;$i++) {
		$res[] = $bdb->queryRow('SELECT * FROM Server WHERE ServerID = '.$i);
		$res2[] = $bdb->queryRow('SELECT * FROM Server WHERE ServerID = '.rand(1,20));
		unset($res);
		unset($res2);
		echo "\n".showMemory('after'.$i);
	}
	echo "\n".showMemory('end'.$i);
}


function runLoop($bdb) {
	echo "\n".showMemory('after1');
	$res = array();
	for ($i=0;$i<1000;$i++) {
		$res[] = $bdb->fetchRow('SELECT * FROM Server WHERE ServerID = '.$i);
		$res2[] = $bdb->fetchRow('SELECT * FROM Server WHERE ServerID = '.rand(1,20));
		unset($res);
		unset($res2);
		echo "\n".showMemory('after'.$i);
	}
	echo "\n".showMemory('end'.$i);
}

function showMemory($description = '') {
	$iniLimit = ini_get('memory_limit');
	$pos = stripos ($iniLimit, 'm');
	if(is_numeric($pos)) {
		$limit = substr($iniLimit, 0, $pos);
		$hardLimit = $limit * 1024 * 1024;
		$softLimit = round($hardLimit * 0.7);
		$warnLimit = round($softLimit * 0.8);
	} else {
		throw new PEAR_Exception('Please specify memory_limit in ini file, sample: memory_limit=128M');
	}

	$current = memory_get_usage();
	$peak =  memory_get_peak_usage();
	if(!is_numeric($current) || !is_numeric($peak) || $current == 0 || $peak == 0) {
		throw new PEAR_Exception('Could not get memory usage...');
	}

	return $description.' - Using ' . $current . ' bytes (peak ' . $peak . '), limits (soft: ' . $softLimit . ' ' . round(($current / $softLimit) * 100, 1) . '%, hard: ' . $hardLimit . ' ' . round(($current / $hardLimit) * 100, 1) . '%)';
}
?>