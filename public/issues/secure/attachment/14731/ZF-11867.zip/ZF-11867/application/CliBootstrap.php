<?php

class CliBootstrap extends Zend_Application_Bootstrap_Bootstrap
{
	protected function _initApp()
	{
		$this->bootstrap('FrontController');

		$this->frontController->setRouter(new Apex_ControllerRouter_Cli());
		$this->frontController->setRequest(new Zend_Controller_Request_Simple());
		$this->frontController->setParam('noViewRenderer', true);

		echo 'CLI Bootstrap' . PHP_EOL;
	}
}