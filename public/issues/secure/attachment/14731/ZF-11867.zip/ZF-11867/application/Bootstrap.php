<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
	public function _initApp()
	{
		echo 'App Bootstrap' . PHP_EOL;
	}
}