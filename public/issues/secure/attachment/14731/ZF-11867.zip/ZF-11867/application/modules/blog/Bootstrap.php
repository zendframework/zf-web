<?php

class Blog_Bootstrap extends Zend_Application_Module_Bootstrap
{
	public function _initApp()
	{
		echo 'Blog Bootstrap' . PHP_EOL;
	}
}