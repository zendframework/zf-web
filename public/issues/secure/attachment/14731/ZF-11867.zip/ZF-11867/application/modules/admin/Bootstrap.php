<?php

class Admin_Bootstrap extends Zend_Application_Module_Bootstrap
{
	public function _initApp()
	{
		echo 'Admin Bootstrap' . PHP_EOL;
	}
}