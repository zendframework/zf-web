<?php

class Apex_ControllerRouter_Cli extends Zend_Controller_Router_Abstract
{
    public function route(Zend_Controller_Request_Abstract $dispatcher)
    {
        $opts = new Zend_Console_Getopt(array(
            'module|m-w' => 'Module name (optional)',
            'controller|c=w' => 'Controller name (required)',
            'action|a=w' => 'Action name (required)'
        ), $this->isolateMvcArgs());

        Zend_Registry::set('Opts', $opts);

        $dispatcher->setModuleName($opts->getOption('m'));
        $dispatcher->setControllerName($opts->getOption('c'));
        $dispatcher->setActionName($opts->getOption('a'));

        return $dispatcher;
    }

    public function assemble($userParams, $name = null, $reset = false, $encode = true)
    {
        throw new Exception('Not implemented.');
    }

    protected function isolateMvcArgs()
    {
        $options = array($_SERVER['argv'][0]);

        foreach ($_SERVER['argv'] as $key => $value) {
            if (in_array($value, array('--module', '-m', '--controller', '-c', '--action', '-a'))) {
                $options[] = $value;
                $options[] = $_SERVER['argv'][$key + 1];
            }
        }

        return $options;
    }
}