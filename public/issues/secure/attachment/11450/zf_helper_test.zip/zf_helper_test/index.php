<?php
error_reporting(E_ALL | E_STRICT);
set_include_path('./libs');

require_once 'Zend/Loader.php';
Zend_Loader::registerAutoload();

/**
 * Front controller
 */
$front = Zend_Controller_Front::getInstance();
$front->throwExceptions(true);
$front->setParam('noErrorHandler', true);
$front->setParam('useDefaultControllerAlways', false);

/**
 * Where are our modules' controllers
 */
$front->setModuleControllerDirectoryName('./');
$front->addModuleDirectory('./application/modules');

$viewRenderer = Zend_Controller_Action_HelperBroker::getStaticHelper('viewRenderer');

$viewRenderer->setViewBasePathSpec('./application/views');
$viewRenderer->setViewScriptPathSpec(':module/:controller/:action.:suffix');

$viewRenderer->setView(new Zend_View());
$viewRenderer->view->addHelperPath('./application/views/helpers', 'MyZend_View_Helper');

/**
 * Go go go!
 */
$front->dispatch();
?>