<?php
class Admin_IndexController extends Zend_Controller_Action
{

    public function indexAction()
    {
        $this->view->say = 'HELLO FROM ADMIN MODULE';
    }

	public function testAction()
	{
		$this->view->say = 'xx';
//		$this->renderScript('admin/index/index.phtml');
	}
}