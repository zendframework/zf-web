<?php
require_once 'Zend/Search/Lucene.php';

$index = new Zend_Search_Lucene('/tmp/lucene.user.index', TRUE);

# sample data
$results = array(
  0 =>  array(
             'uid'       => 'jboonstra',
             'email'     => 'joel@example.com',
             'firstname' => 'joel',
             'lastname'  => 'boonstra',
        ),
  1 =>  array(
             'uid'       => 'ron',
             'email'     => 'ron-ats@example.com',
             'firstname' => 'ron',
             'lastname'  => 'veenstra',
        ),
  2 =>  array(
             'uid'       => 'alan',
             'email'     => 'alan@example.com',
             'firstname' => 'alan',
             'lastname'  => 'ritari',
        ),
);



foreach ($results as $user) {

  $doc   = new Zend_Search_Lucene_Document();
  $contents = sanitize($user['firstname'].' '.$user['lastname'].' '.$user['email']);

  $doc->addField(Zend_Search_Lucene_Field::Text('uid',sanitize($user['uid'])));
  $doc->addField(Zend_Search_Lucene_Field::UnIndexed('created', time()));
  $doc->addField(Zend_Search_Lucene_Field::UnStored('contents',sanitize($contents)));

  $index->addDocument($doc);
}

$index->commit();
echo $index->count()." documents indexed.\n";

function sanitize($input) {
  return iconv('ISO-8859-1', 'ASCII//TRANSLIT', $input);
}
?>
