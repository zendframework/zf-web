<?php
require_once 'Zend/Search/Lucene.php';

$index = new Zend_Search_Lucene('/tmp/lucene.user.index');
echo "Index contains {$index->count()} documents.\n";

$query = 'joel';

$hits = $index->find(sanitize($query));
print "Found ".count($hits)." hits.\n";
print_r($hits);

function sanitize ($input) {
  return iconv('ISO-8859-1', 'ASCII//TRANSLIT', $input);
}

