<?php

define('ZEND_INCLUDE','../../Zend_Framework/library');

$includePath = get_include_path();
$includePath.= PATH_SEPARATOR . realpath(dirname(__FILE__)).'/'.ZEND_INCLUDE;
set_include_path($includePath);


require_once 'Zend/Amf/Server.php';

$server = new Zend_Amf_Server();

$server->addDirectory(dirname(__FILE__) .'/services/');
$server->setProduction(false);
$response = $server->handle();
echo $response;

?>