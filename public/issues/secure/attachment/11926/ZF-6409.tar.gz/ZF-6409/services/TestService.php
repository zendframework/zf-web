<?php
class TestService {
    function __construct() {        
        //Construction...
    }
    
    /**
     * @return string
     */
    public function testfunc()
    {
        return 'testfunc';
    }
}