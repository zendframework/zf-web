<?php

class Default_Model_TestDefault extends Zend_Db_Table
{
	public function printName ()
	{
		return 'Default_Model_TestDefault';
	}
}