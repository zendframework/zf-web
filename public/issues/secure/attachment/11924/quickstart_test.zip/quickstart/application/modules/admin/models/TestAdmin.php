<?php

class Admin_Model_TestAdmin extends Zend_Db_Table
{
	public function printName ()
	{
		return 'Admin_Model_TestAdmin';
	}
}