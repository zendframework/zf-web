<?php

class Adminservices_Model_TestAdminservices extends Zend_Db_Table
{
	public function printName ()
	{
		return 'Adminservices_Model_TestAdminservices';
	}
}