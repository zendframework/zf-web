import flex.messaging.io.amf.client.AMFConnection;
import flex.messaging.io.amf.client.exceptions.ClientStatusException;
import flex.messaging.io.amf.client.exceptions.ServerStatusException;
import flex.messaging.messages.AcknowledgeMessage;
import flex.messaging.messages.RemotingMessage;

/**
 * 
 */


public class TestAMFConnection {

	/**
	 * 
	 */
	public TestAMFConnection() {

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		AMFConnection amfConnection = new AMFConnection();
		amfConnection.setObjectEncoding(3);
		amfConnection.setInstantiateTypes(false);
		 
		Object[] args1 = new Object[1];
		args1[0] = new String[]{"a","b"};
		try {
			amfConnection.connect("http://localhost/PHPArray-debug/gateway.php");
		} catch (ClientStatusException e1) {
			e1.printStackTrace();
		}
		 
		RemotingMessage message = new RemotingMessage();
		message.setMessageId(flex.messaging.util.UUIDUtils.createUUID());
		message.setOperation("testarray");
		message.setBody(args1);
		message.setSource("PHPSvc");
		message.setDestination("PHPSvc");
		
        amfConnection.setObjectEncoding(3);
        amfConnection.setInstantiateTypes(false);
		
		Object returnValue = null;
		
		try {
			returnValue = amfConnection.call(null, message);
		} catch (ClientStatusException e) {

			e.printStackTrace();
		} catch (ServerStatusException e) {

			e.printStackTrace();
		}
		
		Object msg = ((AcknowledgeMessage) returnValue).getBody();

	}

}
