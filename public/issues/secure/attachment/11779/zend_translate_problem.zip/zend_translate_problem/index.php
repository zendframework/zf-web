<?php
/**
 * Reproducing Zend_Translate getList cache bug
 * 
 * @author	Joseph Chereshnovsky <joseph.chereshnovsky@gmail.com>
 * @version	1.0
 */

// Init application
define('APP_PATH',		realpath(dirname(__FILE__)));
define('APP_DATA',	APP_PATH . '/lang');
define('APP_CACHE',		APP_PATH . '/tmp');

require_once 'Zend/Translate.php';
require_once 'Zend/Cache.php';

/**
 * Setup cache and translation adapter 
 */

// initialize translation cache
$cache = Zend_Cache::factory(
		  'Core'
		, 'File'
		, array(
			  'caching'		=> true
			, 'lifetime'	=> 900
			, 'automatic_serialization'	=> true
			, 'automatic_cleaning_factor'	=> 20
			, 'cache_id_prefix'				=> 'Translate'
			)
		, array(
			  'hashed_directory_level' => 0
			, 'cache_dir'	=> APP_CACHE
		)
    );

Zend_Translate::setCache($cache);

$translate = new Zend_Translate('tmx', APP_DATA . '/general.tmx');

/**
 * Reproducing error 
 */
$availLangs = $translate->getList();
var_dump($availLangs);