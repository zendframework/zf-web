<?php

class IndexController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
		$title = $this->_request->getParam('title', null);
		Zend_Debug::dump($title);
    }
    
    public function gohereAction()
    {
		echo('Hello World');
    }


}

