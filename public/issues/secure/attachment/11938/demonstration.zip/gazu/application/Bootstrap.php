<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
	
    protected function _initDoctype()
    {
        $this->bootstrap('view');
        $view = $this->getResource('view');
        $view->doctype('XHTML1_STRICT');
    }

	public function _initNavigator()
	{
    	$pages = new Zend_Navigation($this->getNavArray());

		$this->bootstrap('view');
		
        $view = $this->getResource('view');
    	
    	$view->navigation($pages);
    	return $view;
	}

	private function getNavArray()
	{
		return array(
		    array(
		        'label'      => 'Welcome',
		        'module'     => 'default',
		        'controller' => 'index',
		    	'action'	 => 'index'
		    ),
		    array(
		        'label'      => 'Archives',
		    	'title'      => 'View Weblog Archives',
		        'module'     => 'default',
		        'controller' => 'index',
		        'action'     => 'archives'
			),
		    array(
		        'label'      => 'Authors',
		    	'title'      => 'Authors Control Panel',
		        'module'     => 'default',
		        'controller' => 'author',
		        'action'     => 'index',
		    	'resource'   => 'author'
		    ),
		    array(
		        'label'      => 'Login',
		    	'title'      => 'Click Here To Login',
		        'module'     => 'default',
		        'controller' => 'login',
		        'action'     => 'index',
		        'resource'   => 'login'
		    ),
		    array(
		        'label'      => 'Logout',
		    	'title'      => 'Click Here To Logout',
		        'module'     => 'default',
		        'controller' => 'logout',
		        'action'     => 'index',
		        'resource'   => 'logout'
		    ),
		    array(
		        'label'      => 'Profiles',
		    	'title'      => 'View Author Profiles',
		        'module'     => 'default',
		        'controller' => 'profiles',
		        'action'     => 'index',
		        'resource'   => 'profiles'
		    ),
		    array(
		        'label'      => 'Setup',
		    	'title'      => 'View Your Setup',
		        'module'     => 'default',
		        'controller' => 'setup',
		        'action'     => 'index',
		        'resource'   => 'setup'
		    ),
		    array(
		        'label'      => 'Administration',
		    	'title'      => 'System Administration',
		        'module'     => 'admin',
		        'controller' => 'index',
		        'action'     => 'index',
		        'resource'   => 'admin'
		    ),
		    array(
		        'label'      => 'Register',
		    	'title'      => 'Click Here To Register',
		        'module'     => 'default',
		        'controller' => 'register',
		        'action'     => 'index',
		        'resource'   => 'login'
		    ),
		);
	}
	
}

