<?php
set_include_path('/path/');
				 
require_once 'Zend/Loader/Autoloader.php';
Zend_Loader_Autoloader::getInstance();

// if 'filterPrefixPath' added before of 'rules' not caused problem
$options = array(
	'target' => ':controller/:action',
	'rules'  => array(
		':action'     => 'Custom',
		':controller' => 'Word_CamelCaseToDash'
	),
	'filterPrefixPath' => array('My_Filter_' => 'My/Filter/'),
);

$filter = new Zend_Filter_Inflector(new Zend_Config($options));

$source = array('controller' => 'FooBar',
				'action'     => 'index');

echo $filter->filter($source);
