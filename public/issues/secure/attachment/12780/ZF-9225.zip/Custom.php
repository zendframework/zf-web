<?php
require_once 'Zend/Filter/Interface.php';

class My_Filter_Custom implements Zend_Filter_Interface
{
	public function filter($value)
	{
		return $value . '-foo';	
	}
}