-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 08, 2010 at 12:39 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `reviews`
--

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` tinyint(3) NOT NULL,
  `restaurantName` varchar(50) character set latin2 NOT NULL,
  `icon` varchar(150) NOT NULL,
  `starRating` varchar(150) NOT NULL,
  `starImageLoc` varchar(150) NOT NULL,
  `reviewSubmitDate` varchar(20) NOT NULL,
  `userName` varchar(30) character set latin2 NOT NULL,
  `description` varchar(60) character set latin2 NOT NULL,
  PRIMARY KEY  (`userName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `restaurantName`, `icon`, `starRating`, `starImageLoc`, `reviewSubmitDate`, `userName`, `description`) VALUES
(3, 'GABEL AND LOFFEL', '../src/assets/images/review_user_icons/reviewPopupIcon01.png', '5 stars', '../src/assets/images/review_stars/reviewPopupStar05.png', 'Past 12 Months', 'Deutsch Darling', 'It''s my favorite cafe in town. Cheers, Gabel and Löffel! '),
(3, 'GABEL AND LOFFEL', '../src/assets/images/review_user_icons/reviewPopupIcon02.png', '2 stars', '../src/assets/images/review_stars/reviewPopupStar02.png', 'Past 6 Months', 'Phil', 'This is one rowdy place! Bring your earplugs.'),
(3, 'GABEL AND LOFFEL', '../src/assets/images/review_user_icons/reviewPopupIcon03.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past Month', 'K.W. ', 'It''s worth the trip, even if German food is not your thing!'),
(3, 'GABEL AND LOFFEL', '../src/assets/images/review_user_icons/reviewPopupIcon04.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past Week', 'Phillip R. ', 'Who doesn''t like an all-you-can-drink-beer keg???'),
(8, 'LAKE WALLABY', '../src/assets/images/review_user_icons/reviewPopupIcon05.png', '5 stars', '../src/assets/images/review_stars/reviewPopupStar05.png', 'Past 6 Months', 'Missy H.', 'I order the Vegemite Prawns everytime!'),
(8, 'LAKE WALLABY', '../src/assets/images/review_user_icons/reviewPopupIcon06.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past 12 Months', 'Keith C.', 'And I thought my grilling was good.'),
(8, 'LAKE WALLABY', '../src/assets/images/review_user_icons/reviewPopupIcon07.png', '5 stars', '../src/assets/images/review_stars/reviewPopupStar05.png', 'Past 6 Months', 'Kevin S.', 'There ain''t nothin'' like it. Not even down under. '),
(10, 'MERIDIEN GRILL', '../src/assets/images/review_user_icons/reviewPopupIcon08.png', '5 stars', '../src/assets/images/review_stars/reviewPopupStar05.png', 'Past Month', 'D. Thomas', 'Meridien Grill is a great place to check out vegan hipsters.'),
(10, 'MERIDIEN GRILL', '../src/assets/images/review_user_icons/reviewPopupIcon09.png', '5 stars', '../src/assets/images/review_stars/reviewPopupStar05.png', 'Past 6 Months', 'Kat V.', 'The Blue Lake beans are to die for!'),
(10, 'MERIDIEN GRILL', '../src/assets/images/review_user_icons/reviewPopupIcon10.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past 12 Months', 'Smith D.', 'My favorite place to work on my screenplay.'),
(15, 'STOVETOP SURPRISE', '../src/assets/images/review_user_icons/reviewPopupIcon11.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past Month', 'Tommy B. ', 'I can''t believe it! I actually liked the avocado ice cream!'),
(15, 'STOVETOP SURPRISE', '../src/assets/images/review_user_icons/reviewPopupIcon12.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past 6 Months', 'Kendra G.', 'From Pesto Salmon Potato Loaf to Creme Brulee Loaf, everythi'),
(7, 'LE REVE', '../src/assets/images/review_user_icons/reviewPopupIcon13.png', '5 stars', '../src/assets/images/review_stars/reviewPopupStar05.png', 'Past 6 Months', 'Steve S.', 'I''m allergic to dogs, and they were everywhere! '),
(7, 'LE REVE', '../src/assets/images/review_user_icons/reviewPopupIcon14.png', '5 stars', '../src/assets/images/review_stars/reviewPopupStar05.png', 'Past 6 Months', 'Mademoiselle3', 'Magnificent! Next time, I''m packing a bag and moving in!'),
(7, 'LE REVE', '../src/assets/images/review_user_icons/reviewPopupIcon01.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past Month', 'Tina F. ', 'Pajamas in public? Now that''s something I can get behind.'),
(7, 'LE REVE', '../src/assets/images/review_user_icons/reviewPopupIcon02.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past Week', 'Pierre', 'Masterful execution. I definitely recommend this place!'),
(21, 'PIERRE''S PLATTER', '../src/assets/images/review_user_icons/reviewPopupIcon03.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past Month', 'Aaron W.', 'This place is beautiful, but a little too pretentious.'),
(21, 'PIERRE''S PLATTER', '../src/assets/images/review_user_icons/reviewPopupIcon04.png', '2 stars', '../src/assets/images/review_stars/reviewPopupStar02.png', 'Past 6 Months', 'Brittany T.', 'I''ll partake in smashing plates anytime.'),
(21, 'PIERRE''S PLATTER', '../src/assets/images/review_user_icons/reviewPopupIcon05.png', '2 stars', '../src/assets/images/review_stars/reviewPopupStar02.png', 'Past Month', 'H. Thompson', 'A meal in a cave? I''m in!'),
(11, 'RUE DE FAIM', '../src/assets/images/review_user_icons/reviewPopupIcon06.png', '1 star', '../src/assets/images/review_stars/reviewPopupStar01.png', 'Past 12 Months', 'M. Croquet', 'The valet are all so handsome! But the food...'),
(11, 'RUE DE FAIM', '../src/assets/images/review_user_icons/reviewPopupIcon07.png', '2 stars', '../src/assets/images/review_stars/reviewPopupStar02.png', 'Past Month', 'T. Watley ', 'I''ve never experienced bouillion quite like this!'),
(11, 'RUE DE FAIM', '../src/assets/images/review_user_icons/reviewPopupIcon08.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past 12 Months', 'Felipe C.', 'Visiting Rue de Faim is always an adventure. '),
(11, 'RUE DE FAIM', '../src/assets/images/review_user_icons/reviewPopupIcon09.png', '1 star', '../src/assets/images/review_stars/reviewPopupStar01.png', 'Past 6 Months', 'Christin T. ', 'Be prepared to spend several hours at this place. '),
(16, 'SMALL PLATES', '../src/assets/images/review_user_icons/reviewPopupIcon10.png', '5 stars', '../src/assets/images/review_stars/reviewPopupStar05.png', 'Past Month', 'Monsieur Q.', 'Superb! '),
(16, 'SMALL PLATES', '../src/assets/images/review_user_icons/reviewPopupIcon11.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past 6 Months', 'Melanie O.', 'I took my family here and they couldn''t be more pleased. '),
(16, 'SMALL PLATES', '../src/assets/images/review_user_icons/reviewPopupIcon12.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past Month', 'Wine Lover', 'Romantic, artistic, and filled with my favorite beverage.'),
(1, 'ACQUA E FARINA', '../src/assets/images/review_user_icons/reviewPopupIcon13.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past 6 Months', 'PizzaLover', 'Best pizza in town, hands down!'),
(1, 'ACQUA E FARINA', '../src/assets/images/review_user_icons/reviewPopupIcon14.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past Week', 'Steph L.', 'Great for a quick casual bite.'),
(1, 'ACQUA E FARINA', '../src/assets/images/review_user_icons/reviewPopupIcon01.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past Month', 'Cynical Steve', 'It''s a good thing we like to get in touch with nature!'),
(1, 'ACQUA E FARINA', '../src/assets/images/review_user_icons/reviewPopupIcon02.png', '2 stars', '../src/assets/images/review_stars/reviewPopupStar02.png', 'Past 12 Months', 'Kelly B. ', 'Freshness makes all the difference!'),
(6, 'IL PIATTO DI PASTA', '../src/assets/images/review_user_icons/reviewPopupIcon03.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past Month', 'Trina P. ', 'You guys are lifesavers!'),
(6, 'IL PIATTO DI PASTA', '../src/assets/images/review_user_icons/reviewPopupIcon04.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past 6 Months', 'Lorraine G. ', 'This place gives me a chance to have Girls Night!'),
(6, 'IL PIATTO DI PASTA', '../src/assets/images/review_user_icons/reviewPopupIcon05.png', '5 stars', '../src/assets/images/review_stars/reviewPopupStar05.png', 'Past 6 Months', 'Mom of 4', 'My kids love Il Piatto di Pasta! '),
(6, 'IL PIATTO DI PASTA', '../src/assets/images/review_user_icons/reviewPopupIcon06.png', '2 stars', '../src/assets/images/review_stars/reviewPopupStar02.png', 'Past Month', 'Ben M.', 'My wife and I drop our parents off at Il Piatto di Pasta.'),
(12, 'SALSA ROSSA', '../src/assets/images/review_user_icons/reviewPopupIcon07.png', '5 stars', '../src/assets/images/review_stars/reviewPopupStar05.png', 'Past Month', 'Giovanni F. ', 'They make''a the sauce just like my mama make''a the sauce!'),
(12, 'SALSA ROSSA', '../src/assets/images/review_user_icons/reviewPopupIcon07.png', '5 stars', '../src/assets/images/review_stars/reviewPopupStar05.png', 'Past 6 Months', 'Blue Bicyclette', 'Fantastic! My favorite Italian restaurant in Meridien.'),
(12, 'SALSA ROSSA', '../src/assets/images/review_user_icons/reviewPopupIcon08.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past 12 Months', 'Phillipe C. ', 'Definitely an awesome date spot.'),
(17, 'SPAGHETTI ZONE', '../src/assets/images/review_user_icons/reviewPopupIcon09.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past Week', 'Bella T.', 'Spaghetti just like mama used to make!'),
(17, 'SPAGHETTI ZONE', '../src/assets/images/review_user_icons/reviewPopupIcon10.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past 6 Months', 'R. Moretti', 'It doesn''t get more festive than Spaghetti Zone.'),
(17, 'SPAGHETTI ZONE', '../src/assets/images/review_user_icons/reviewPopupIcon11.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past 6 Months', 'Cassie M. ', 'I just love their jingle!'),
(17, 'SPAGHETTI ZONE', '../src/assets/images/review_user_icons/reviewPopupIcon12.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past Month', 'Devon V.', 'The flying spaghetti definitely keeps the kids entertained. '),
(4, 'GARY''S GARI', '../src/assets/images/review_user_icons/reviewPopupIcon13.png', '2 stars', '../src/assets/images/review_stars/reviewPopupStar02.png', 'Past Month', 'L. Townsend', 'I''ve never had so much ginger in my life.'),
(4, 'GARY''S GARI', '../src/assets/images/review_user_icons/reviewPopupIcon14.png', '5 stars', '../src/assets/images/review_stars/reviewPopupStar05.png', 'Past 6 Months', 'Yoko R.', 'This is my favorite sushi. Ginger makes everything better!'),
(4, 'GARY''S GARI', '../src/assets/images/review_user_icons/reviewPopupIcon01.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past 12 Months', 'Miyumi K. ', 'Thank goodness for Gary''s "Gari".'),
(4, 'GARY''S GARI', '../src/assets/images/review_user_icons/reviewPopupIcon02.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past Month', 'Ken B.', 'I love the Ginger Ponzu. It''s a must on any roll!'),
(5, 'HAPPY FISH', '../src/assets/images/review_user_icons/reviewPopupIcon03.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past Month', 'Lynn Z.', 'I had never tried sushi before Happy Fish. I''m happy I did!'),
(5, 'HAPPY FISH', '../src/assets/images/review_user_icons/reviewPopupIcon04.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past 6 Months', '143Fish', 'Happy Fish makes me happy! There''s so much food.'),
(5, 'HAPPY FISH', '../src/assets/images/review_user_icons/reviewPopupIcon05.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past Week', 'K.J.', 'The chefs are so nice. It was delicious.'),
(13, 'ONE-TON ONO', '../src/assets/images/review_user_icons/reviewPopupIcon06.png', '5 stars', '../src/assets/images/review_stars/reviewPopupStar05.png', 'Past Month', 'J. Martens', 'I''ve never been more full in my life! '),
(13, 'ONE-TON ONO', '../src/assets/images/review_user_icons/reviewPopupIcon07.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past Month', 'Robert W.', 'Great collection of sake!'),
(13, 'ONE-TON ONO', '../src/assets/images/review_user_icons/reviewPopupIcon08.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past 12 Months', 'Sushi Warrior', 'I had a fun trying to figure out what to with all the food!'),
(18, 'SOMETHING FISHY', '../src/assets/images/review_user_icons/reviewPopupIcon09.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past Month', 'P. Ko', 'Keep that sake coming!'),
(18, 'SOMETHING FISHY', '../src/assets/images/review_user_icons/reviewPopupIcon10.png', '2 stars', '../src/assets/images/review_stars/reviewPopupStar02.png', 'Past 6 Months', 'E. Hwangbo', 'I can''t make it through the meal without falling asleep!'),
(18, 'SOMETHING FISHY', '../src/assets/images/review_user_icons/reviewPopupIcon11.png', '2 stars', '../src/assets/images/review_stars/reviewPopupStar02.png', 'Past 6 Months', 'C. Burkhardt', 'There might be something fishy going on at Something Fishy.'),
(18, 'SOMETHING FISHY', '../src/assets/images/review_user_icons/reviewPopupIcon12.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past 12 Months', 'Gloria R.', 'I knocked over a Japanese vase. Oops.'),
(20, 'SUSHI HEAVEN', '../src/assets/images/review_user_icons/reviewPopupIcon14.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past 6 Months', 'Ryan W. ', 'It''s a peaceful place with a wild menu. '),
(20, 'SUSHI HEAVEN', '../src/assets/images/review_user_icons/reviewPopupIcon01.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past Month', 'A. Kingston', 'Here, the sushi chefs don''t yell at you when you enter. '),
(20, 'SUSHI HEAVEN', '../src/assets/images/review_user_icons/reviewPopupIcon02.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past Month', 'Yuki G.', 'The sushi is so fresh! I eat here at least once a week.'),
(2, 'CELERY', '../src/assets/images/review_user_icons/reviewPopupIcon03.png', '5 stars', '../src/assets/images/review_stars/reviewPopupStar05.png', 'Past Week', 'VegGirl', 'Celery is deliciously green and fibrous! I can''t get enough!'),
(2, 'CELERY', '../src/assets/images/review_user_icons/reviewPopupIcon04.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past Month', 'P. Smith', 'I''m a sucker for lighting that makes me look good.'),
(2, 'CELERY', '../src/assets/images/review_user_icons/reviewPopupIcon05.png', '2 stars', '../src/assets/images/review_stars/reviewPopupStar02.png', 'Past 6 Months', 'Jeff K.', 'I''m not a vegetarian, but it''s a perfect spot for a date.'),
(9, 'UPTOWN SPROUTS', '../src/assets/images/review_user_icons/reviewPopupIcon06.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past 6 Months', 'J. Wallace', 'It''s impressive, and everyone can find something they like.'),
(9, 'UPTOWN SPROUTS', '../src/assets/images/review_user_icons/reviewPopupIcon07.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past Week', 'FengShui', 'Balanced interior. I''m a fan!'),
(9, 'UPTOWN SPROUTS', '../src/assets/images/review_user_icons/reviewPopupIcon08.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past 12 Months', 'Caroline H.', 'Great music and great wine selection as well!'),
(14, 'VEGAN HEART', '../src/assets/images/review_user_icons/reviewPopupIcon09.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past Month', 'Ayla J.', 'I feel like I could run a marathon after eating here.'),
(14, 'VEGAN HEART', '../src/assets/images/review_user_icons/reviewPopupIcon10.png', '2 stars', '../src/assets/images/review_stars/reviewPopupStar02.png', 'Past 6 Months', 'Winnie K.', 'When I need my fill of fiber, I head here! '),
(14, 'VEGAN HEART', '../src/assets/images/review_user_icons/reviewPopupIcon11.png', '4 stars', '../src/assets/images/review_stars/reviewPopupStar04.png', 'Past 12 Months', 'Dominic F.', 'I go to hang out with the woodland creatures.'),
(19, 'YUM PHO YOU', '../src/assets/images/review_user_icons/reviewPopupIcon12.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past 6 Months', 'Belia C.', 'I love to cook, but don''t like the mess. That''s why I go!'),
(19, 'YUM PHO YOU', '../src/assets/images/review_user_icons/reviewPopupIcon13.png', '3 stars', '../src/assets/images/review_stars/reviewPopupStar03.png', 'Past Month', 'R. Craven', 'It''s a great source of protein for vegetarians like myself.'),
(19, 'YUM PHO YOU', '../src/assets/images/review_user_icons/reviewPopupIcon14.png', '5 stars', '../src/assets/images/review_stars/reviewPopupStar05.png', 'Past Month', 'Erica E.', ' I always make new friends when I eat at Yum Pho You.');
