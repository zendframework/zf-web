<?php

/**
 * ErrorController - The default error controller class
 * 
 * @author
 * @version 
 */

require_once 'Zend/Controller/Action.php';

class ErrorController extends Zend_Controller_Action {
	
	/**
	 * This action handles  
	 *    - Application errors
	 *    - Errors in the controller chain arising from missing 
	 *      controller classes and/or action methods
	 */
	public function errorAction() {
		$errors = $this->_getParam ( 'error_handler' );
		
		
			switch ($errors->type) {
				case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_CONTROLLER :
				case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_ACTION :
					// 404 error -- controller or action not found                
					$this->getResponse ()->setRawHeader ( 'HTTP/1.1 404 Not Found' );
					$this->view->title = "Page not found";
					$this->view->message = "The page you requested cannot be found.";
					break;
				default :
					$this->view->title = "Error";
					$this->view->message = "Oops. An error occurred.";
					break;
			}
	
	}
	

}
