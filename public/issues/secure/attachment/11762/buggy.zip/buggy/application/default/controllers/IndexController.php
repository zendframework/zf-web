<?php

/**
 * IndexController - The default controller class
 * 
 * @author Wouter Samaey
 * @version 1.0
 */

require_once 'Zend/Controller/Action.php';

class IndexController extends Zend_Controller_Action {
	
	public function indexAction() {
		
	}
}