<?php
/**
 * @author Wouter Samaey
 * @version 1.0
 */

/**
THE TEST URL IS:

http://127.0.0.1/buggy/public_html/?use_remote=1&debug_session_id=1003&start_debug=1&debug_start_session=1&debug_host=10.37.129.2%2C10.211.55.2%2C192.168.0.193%2C127.0.0.1&debug_no_cache=1234951380201&debug_fastfile=1&debug_port=10137&send_sess_end=1&original_url=http://127.0.0.1/buggy/public_html/

Assuming your documentroot is the same as your workspace

I'm running MAMP with PHP 5.2.5 and ZF 1.7.3.
ZF 1.7.2 doesn't throw the warnings, but every newer version does.

An error log file is placed in the application folder
please update the line below to point to your ZF library
 */

// Environment constants

define ( 'FRAMEWORK_ROOT', realpath ( '/Users/wouter/Business/Frameworks/ZendFramework-1.7.3-minimal/library' ) . '/' );
define ( 'APPLICATION_ROOT', realpath ( '../application/' ) . '/' );


	error_reporting ( E_ALL | E_STRICT );
	ini_set ( 'display_errors', 1 );
	ini_set ( 'log_errors', 1 );
	ini_set ( 'error_log', APPLICATION_ROOT . '/error_log.txt' );
	ini_set ( 'display_startup_errors', 1 );


// Default timezone
date_default_timezone_set ( 'Europe/Brussels' );

// Include path setup
$includeItems = array ();
$includeItems [] = FRAMEWORK_ROOT;
$includeItems [] = realpath ( APPLICATION_ROOT . '/default/models/' );

$includePath = '';
foreach ( $includeItems as $path ) {
	if ($path !== false) {
		$includePath .= $path . PATH_SEPARATOR;
	}
}
set_include_path ( $includePath );

// Load required Zend Components
require_once 'Zend/Loader.php';
Zend_Loader::registerAutoload ();


// Setup controller
$front = Zend_Controller_Front::getInstance ();
$front->addModuleDirectory ( APPLICATION_ROOT );
$front->throwExceptions ( true );

// bootstrap layouts
$layoutOptions = array ('layoutPath' => APPLICATION_ROOT . '/default/layouts', 'layout' => 'default' );
$layout = Zend_Layout::startMvc ( $layoutOptions );

// Doctype
$doctypeHelper = new Zend_View_Helper_Doctype ( );
$doctypeHelper->doctype ( Zend_View_Helper_Doctype::XHTML11 );

// run!
$front->dispatch ();

