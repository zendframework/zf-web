<?php

/**
 * @see Zend_Controller_Action_Helper_ContextSwitch
 */
require_once 'Zend/Controller/Action/Helper/ContextSwitch.php';

/**
 * Simplify Dashboard context switching based on requested format
 *
 * @uses       Zend_Controller_Action_Helper_Abstract
 * @package    iMS
 */
class Test_Controller_Action_Helper_Context extends Zend_Controller_Action_Helper_ContextSwitch {

    public function __construct() {
        parent::__construct();
        $this   ->setContextParam('context')
                ->addContext('dashboard', array('suffix' => 'dashboard','callbacks' => array('init' => array($this,'enableLayout'))))
                ->addContext('html'     , array('suffix' => ''      ))
           
        ;
        $this->init();
    }

    /**
     * Initialize Dashboard context switching
     *
     * @param  string $format
     * @return void
     */
    public function initContext($format = null) {
        $this->_currentContext = null;
        return parent::initContext($format);
    }

    public function disableLayout() {
        require_once 'Zend/Layout.php';
        $layout = Zend_Layout::getMvcInstance();
        if (null !== $layout) {
            $layout->disableLayout();
        }

    }
    public function enableLayout() {
        $this->setAutoDisableLayout(false);
        require_once 'Zend/Layout.php';
        $layout = Zend_Layout::getMvcInstance();
        if (null !== $layout) {
            $layout->enableLayout();
        }
    }
}
