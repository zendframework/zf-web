<?php

require_once 'Zend/Controller/Action.php';

class IndexController extends Zend_Controller_Action {
    
    /**
     * View script suffix
     * @var string
     */
    protected $_viewSuffix      = 'phtml';

    /**
     * Inflector target
     * @var string
     */
    protected $_inflectorTarget = ':controller/:context:action.:suffix';

    public function init() {
        $this->_helper  ->getHelper('Context')
            ->addActionContext('index'                              , array('dashboard'))
            ->initContext();
    }
    
    public function preDispatch() {
        $this->setContextInflector();
    }

    public function indexAction() {
        $this->view->number = $this->_getParam('number', false);
    }

    /** methods from Zend_Controller_Action extend **/

    /**
     * sets the inflector for the viewRenderer in context mode
     * and give the view the context
     * @return void
     */
    protected function setContextInflector() {
        
        $currentContext = $this->getContext();
        $inflector      = $this->_helper->getHelper('viewRenderer')->getInflector();
        $this->_context = ( $currentContext == '' || $currentContext == 'html' ) ? '' : $currentContext. '/';

        /** not working **/
        $inflector
            ->addFilterRule(':context' ,array('Word_CamelCaseToDash', 'StringToLower'))
            ->setStaticRuleReference('suffix'  , $this->_viewSuffix)
            ->setStaticRuleReference('context' , $this->_context)
            ->setTargetReference($this->_inflectorTarget)
        ;
        
        /** working **/

        /*
        if ($inflector->getRules('context') == false) {
            $inflector
                ->addFilterRule(':context' ,array('Word_CamelCaseToDash', 'StringToLower'));
        }
        $inflector
            ->setStaticRuleReference('suffix'  , $this->_viewSuffix)
            ->setStaticRuleReference('context' , $this->_context)
            ->setTargetReference($this->_inflectorTarget)
        ;
         */
    }
    
    /**
     * Returns the current Context
     *
     * @return string
     */
    protected function getContext() {
        return $this->_helper->getHelper('Context')->getCurrentContext();
    }
}