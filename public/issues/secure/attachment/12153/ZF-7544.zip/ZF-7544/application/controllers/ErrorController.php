<?php

class ErrorController extends Zend_Controller_Action {
    public function __call($m,$a) {
        exit(Zend_Debug::dump($a,"<b>$m</b><br />",false));
    }
}