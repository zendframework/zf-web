<?php
class DojoController extends Zend_Controller_Action
{
    public function preDispatch()
    {
        $dojoType = $this->_getParam('dojoType', 'programmatic');
        if ($dojoType == 'declarative') {
            Zend_Dojo_View_Helper_Dojo::setUseDeclarative();
        }
        $this->view->dojoType = $dojoType;
    }

    public function indexAction()
    {
        // $this->_helper->redirector('preview');
    }

    public function previewAction()
    {
        $this->view->form = new My_Form_Test;
    }

    public function radioAction()
    {
    }
}
