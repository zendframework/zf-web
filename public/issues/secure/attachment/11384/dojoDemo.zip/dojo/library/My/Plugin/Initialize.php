<?php
/**
 * Plugin to initialize application state
 * 
 * @uses       Zend_Controller_Plugin_Abstract
 * @package    My
 * @subpackage Plugin
 * @version    $Id: $
 */
class My_Plugin_Initialize extends Zend_Controller_Plugin_Abstract
{
    public function __construct($basePath, $env = 'production')
    {
        $this->env      = $env;

        $this->basePath = $basePath;
        $this->appPath  = $this->basePath . '/application';
        $this->libPath  = $this->basePath . '/library';
        $this->pubPath  = $this->basePath . '/public';
    }

    public function routeStartup()
    {
        $this->initView();
    }

    public function initView()
    {
        $layout = Zend_Layout::startMvc(array(
            'layoutPath' => $this->appPath . '/views/layouts'
        ));

        $view = $layout->getView();
        $view->addHelperPath('Zend/Dojo/View/Helper/', 'Zend_Dojo_View_Helper');
        $view->doctype('XHTML1_TRANSITIONAL');
        $view->headTitle('Demo Application');
        // $view->dojo()->addStylesheet(Zend_Dojo_View_Helper_Dojo_Container::CDN_BASE . '1.1/dojo/resources/dojo.css')
        $view->dojo()->setDjConfigOption('usePlainJson', true)
                     ->setDjConfigOption('isDebug', true)
                     ->addStylesheetModule('dijit.themes.tundra')
                     ->setLocalPath('/js/dojo/dojo.js')
                     ->addStylesheet('/js/dojo/resources/dojo.js')
                     ->enable( );

        return $this;
    }
}
