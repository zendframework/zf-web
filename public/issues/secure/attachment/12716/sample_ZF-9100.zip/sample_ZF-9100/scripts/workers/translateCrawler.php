<?php
/**
 * My experimental solution to crawl all files for searching for things to translate
 * and from that generate keys to feed poEdit
 *
 * @package     Scripts
 * @subpackage  Experimental
 * @author      Ernest Szulikowski <es241980@gmail.com>
 * @copyright   Ernest Szulikowski <es241980@gmail.com>
 * @version     SVN: $Id: translateCrawler.php 146 2009-12-15 09:45:27Z ernest $
 */

$mpth = __DIR__ . '/../../';
$localepth = $mpth . 'languages/';

//allowed files
$ext = array(
        '\.php', '\.phtml', '\.xml'
);

//custom paths
$paths = array(
        /*'admin' => array(
                'app/modules/admin',
                'app/config/navigation'),*/
        'main' => array(
                'lib/IPMCore', 'app/config/navigation', 'app/modules/admin',
                'app/config/navigation', 'app/modules/default' )
);

//search for what keys
$keys = array (
        //--------pattern,--captouring group (if more than one)
        //array ( '\w',1  )
        'form label' => array ('%(?<!//)\$this->icFormBase\((?:\'[-a-z0-9_]+?\',\s*?){3}\'(.+?)\',\s*?(?:true|false)%sim', 1),
        'group label' => array('%(?<!//)\$this->icGroup\((?:\'[-a-z0-9_]+?\',\s*?){1}\'(.+?)\',%sim', 1),
        //'form element title' => array('%(?!//)(?<=\$this->icFormBase\().+?(?:true|false), \'(_[^\']+?)\'.+?(?=\);)%sm', 1),
        'multiOptions' => array('/(?:(?<==> \')|(?<==>\')|(?<==>  \'))_[^\']+?(?=\')/sim'),
        'XML_navigation' => array('%<(label|title)>(_\w+)</\1>%', 2),
        'custom_validator_messages' => array('/\$validatorMessage\s*->\s*setMessage\s*\(\s*\'([\w%.,]+)\'\s*\);/', 1)
);



/*********************************/

//list of files to search for keys
$filesFound = array();
//list of found content (form keys)
$keysFound = array();


//iterate through allowed paths
foreach ($paths as $title => $path) {

    foreach ($path as $current) {

        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($mpth . $current));

        while($it->valid()) {

            if (!$it->isDot()) {

                //choose only proper files with allowed exensions
                foreach ($ext as $extPreg) {
                    if (preg_match('%((?<=/)|(?<=\\\\))[-a-z0-9_]+?' . $extPreg . '(?!.)%im', $it->getSubPathName() )) {
                        # Successful match
                        $filesFound[$title][$it->getSubPathName()] = $it->key();
                    }
                }
            }
            $it->next();
        }
    }
}


//now we have files (in array: $filesFound), let's search for keys in them
$resultsOfMatches = array();
$duplicateKeys = array();
foreach ($filesFound as $titleForFile => $listOfFiles) {
    foreach ($listOfFiles as $key => $fileName) {

        $contents = file_get_contents($fileName, 'r');
        $tempArr = array();
        $match = false;
        //iterate all preg keys
        foreach ($keys as $keyName => $keyPreg) {
            preg_match_all($keyPreg[0], $contents, $result, PREG_PATTERN_ORDER);
            $d = 0;
            if ( isset($keyPreg[1])) {
                $d = $keyPreg[1];
            }
            if ( !empty ($result[$d]) ) {
                $tempArr[] = $result[$d];
                $match = true;
            }

        }
        if ( $match)
            $resultsOfMatches[$key][$titleForFile] = array_flatten($tempArr);

    }
}//now we have files (in array: $filesFound), let's search for keys in them

//check wheter we had duplicate keys
//$duplicateKeys = array_flatten($resultsOfMatches);
//if ( count($duplicateKeys) != count(array_unique($duplicateKeys)) ) {
//    echo "FATAL ERROR. DUPLICATE TRANSLATION KEYS WERE FOUND: \n";
//    //$okKeys = array_unique($duplicateKeys);
//    foreach ($duplicateKeys as $fk => $fv) {
//        if ( ! array_key_exists($fk, array_unique($duplicateKeys))) {
//            echo " * " . $duplicateKeys[$fk] . "\n" ;
//        }
//    }
//    exit;
//}//check wheter we had duplicate keys

//echo count($duplicateKeys) . " total keys found. \n";


echo "Writing templates \n";

foreach ($paths as $key => $value) {
    echo $key . '---->' ;
    $newFile = new SplFileObject($localepth . 'templates/'. $key . '/' . $key . '.php', 'w+');
    $newFile->fwrite( '<?php' . "\n"  );
    $thisArr = prepare_array($resultsOfMatches, $key);
    foreach ($thisArr as $key => $value) {
        $value = preg_replace('/(\r\n|\r|\n|\t| {2,})/sm', '', $value);
        $newFile->fwrite( '_(\'' . $value . '\');' . "\n"  );
    }


}

echo "Finished. \n";


/******************************************/


function prepare_array ($array, $csvFileName) {
    $tempArr = array();
    foreach ($array as $k => $v ) {
        if (array_key_exists($csvFileName, $v)) {
            $tempArr[] = $v[$csvFileName];
        }
    }
    return array_flatten($tempArr);

}


function array_flatten($arr) {
    $ab = array();
    if(!is_array($arr)) return $ab;
    foreach($arr as $value) {
        if(is_array($value)) {
            $ab = array_merge($ab, array_flatten($value));
        }
        else {
            array_push($ab,$value);
        }
    }
    return $ab;
}