<?php
require dirname(__FILE__).'/../app/global.php';

define('APPLICATION_ENV', 'development');

define('APPLICATION_PATH', realpath(__DIR__ . '/../app'));
define('APPLICATION_ROOT', realpath(__DIR__ . '/../'));

require_once 'Zend/Loader/Autoloader.php';

include_once 'IPMCore/Loader.php';
$autoloader = Zend_Loader_Autoloader::getInstance();
$autoloader->setDefaultAutoloader(array('IPMCore_Loader', 'autoload'));

require_once 'Zend/Application.php';
require_once 'Doctrine.php';

// Create application, bootstrap, and run
$application = new Zend_Application(
    APPLICATION_ENV,
    APPLICATION_PATH . '/config/application.ini'
);

$bootstrap = $application->getBootstrap()->bootstrap('doctrine');

$options = $application->getOption('doctrine');

$cli = new Doctrine_Cli($options);
$cli->run($_SERVER['argv']);
