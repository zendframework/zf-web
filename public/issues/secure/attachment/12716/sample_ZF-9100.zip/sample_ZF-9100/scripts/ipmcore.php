<?php
/**
 * @package
 * @subpackage
 * @author      Ernest Szulikowski <es241980@gmail.com>
 * @copyright   Ernest Szulikowski <es241980@gmail.com>
 * @version     SVN: $Id: ipmcore.php 157 2010-01-05 20:16:06Z ernie24_ernest $
 * @todo		THIS FILE IS OBSOLETE AND NEEDS COMPLETE REWRITING
 */
error_reporting(E_ALL|E_STRICT);
ini_set('display_errors',true);

require __DIR__ . '/../app/global.php';
require 'Zend/Console/Getopt.php';

try {
    $opts = new Zend_Console_Getopt(
        array(
        'tcrawler|t-s' => 'Begin Crawling looking for translation keys. ',
        'new|n' => 'tcrawler: create file from scratch',
        'help|h' => 'Display Help',
        )
    );

    $opts->parse();
}
catch (Zend_Console_Getopt_Exception $e) {
    echo $e->getUsageMessage();
    exit;
}

if (isset ($opts->h ) ) {
    echo $opts->getUsageMessage();
    exit;
}

if (isset ($opts->t ) ) {
    echo "\nCrawling searching for translation keys: \n\n";
    //$args = $opts->getRemainingArgs();
    //print_r($args);
    include __DIR__ . '/workers/translateCrawler.php';
}