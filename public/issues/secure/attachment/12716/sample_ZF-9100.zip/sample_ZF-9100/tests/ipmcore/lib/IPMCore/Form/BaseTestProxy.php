<?php
/**
 *
 *
 * @package
 * @subpackage
 * @author      Ernest Szulikowski <es241980@gmail.com>
 * @copyright   Ernest Szulikowski <es241980@gmail.com>
 * @version     SVN: $Id: BaseTestProxy.php 148 2009-12-23 14:04:11Z ernest $
 */
class BaseTestProxy extends IPMCore_Form_UserFormBase {

//    public function init() {
//        parent::init();
//    }

    public function icFormBase($type, $icType, $elmntId, $label, $required = true,
        $description = null, $value = null, array $options = array()) {
        parent::icFormBase($type, $icType, $elmntId, $label, $required, $description, $value, $options);
//        return $this->icFormBase($type, $icType, $elmntId, $label, $required,
//            $description, $value, $options);
    }

    public function icGroup($name, $groupLegend, array $elements,
        array $options = array()) {
        parent::icGroup($name, $groupLegend, $elements,
            $options );
    }

}

