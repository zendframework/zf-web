<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
*/

/**
 * @author Ernest
 */

require dirname(__FILE__).'/../app/global.php';
// TODO: check include path
ini_set('include_path', ini_get('include_path')
        .PATH_SEPARATOR.'C:/Program Files/PHP/pear'
        .PATH_SEPARATOR.'C:/Program Files/PHP/includes'
);



defined('APPLICATION_PATH')
        || define('APPLICATION_PATH', realpath(dirname(__FILE__) . '/../app'));

if (!defined('APPLICATION_ROOT')) {
    define('APPLICATION_ROOT', realpath(dirname(__FILE__) . '/..'));
}

define('APPLICATION_ENV', 'unit');


require_once 'Zend/Application.php';
require_once 'Doctrine.php';
require_once 'Zend/Application.php';
require_once 'Zend/Loader/Autoloader.php';

include_once 'IPMCore/Loader.php';
$autoloader = Zend_Loader_Autoloader::getInstance();
$autoloader->setDefaultAutoloader(array('IPMCore_Loader', 'autoload'));

$translator = new Zend_Translate('gettext', APPLICATION_ROOT .
                '/languages/' . 'en' . '/main.mo', 'en',
        array( 'disableNotices' => true ) );

Zend_Registry::set('Zend_Translate', $translator);

// Create application, bootstrap, and run
$application = new Zend_Application(
        APPLICATION_ENV,
        APPLICATION_PATH . '/config/application.ini'
);

//$application->getBootstrap()->bootstrap(array(  'session', 'view',
//        'modifiedFrontController', 'routes' ));
$application->bootstrap();
