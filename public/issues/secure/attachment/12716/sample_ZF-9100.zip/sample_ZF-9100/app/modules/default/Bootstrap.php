<?php
/**
 * Bootstraper for Admin module
 * @package     IPMCore
 * @subpackage  Admin
 * @author      Ernest Szulikowski <es241980@gmail.com>
 * @copyright   Ernest Szulikowski <es241980@gmail.com>
 * @version     SVN: $Id: Bootstrap.php 158 2010-01-05 20:16:47Z ernie24_ernest $
 */
class Default_Bootstrap extends Zend_Application_Module_Bootstrap {

//    public function _initTranslate() {
//
//    }


}
