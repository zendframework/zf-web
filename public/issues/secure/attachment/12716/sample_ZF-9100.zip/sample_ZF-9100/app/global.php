<?php
/**
 * @package     IPMCore
 * @subpackage  bootstrap
 * @author      Ernest Szulikowski <es241980@gmail.com>
 * @copyright   Ernest Szulikowski <es241980@gmail.com>
 * @version     SVN: $Id: global.php 159 2010-01-14 21:43:39Z ernie24_ernest $
 */

//$session_save_path = dirname(__FILE__).'/../data/sessions';
//ini_set('session.save_path', $session_save_path);
//ini_set('session.save_handler', 'memcache');

set_include_path(
       realpath( __DIR__.'/../lib')
        //. PATH_SEPARATOR . __DIR__.'/../lib/doctr/doctrine'
        //. PATH_SEPARATOR . __DIR__.'/../lib'
        /* . PATH_SEPARATOR . dirname(__FILE__).'/models'*/
        /* . PATH_SEPARATOR . dirname(__FILE__).'/models/generated'*/
        //. PATH_SEPARATOR . get_include_path()
);
