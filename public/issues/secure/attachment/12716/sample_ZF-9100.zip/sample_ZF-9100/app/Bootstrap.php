<?php
/**
 * Main bootstrap for entire project
 *
 * @package     IPMCore
 * @subpackage  bootstrap
 * @author      Ernest Szulikowski <es241980@gmail.com>
 * @copyright   Ernest Szulikowski <es241980@gmail.com>
 * @version     SVN: $Id: Bootstrap.php 174 2010-02-06 10:12:18Z ernie24_ernest $
 */
class Bootstrap extends Zend_Application_Bootstrap_Bootstrap {



    protected function _initPluginLoaderCache() {
        if ('production' == APPLICATION_ENV) {
            $classFileIncCache =
                    APPLICATION_ROOT . '/data/cache/pluginLoaderCache.php';
            if (file_exists($classFileIncCache)) {
                include_once $classFileIncCache;
            }
            Zend_Loader_PluginLoader::setIncludeFileCache(
                    $classFileIncCache
            );
        }
    }

//    protected function _initModuleAutoload() {
//        $moduleLoader = new Zend_Application_Module_Autoloader(array(
//                        'namespace' => '',
//                        'basePath' => APPLICATION_PATH));
//        return $moduleLoader;
//    }



    protected function _initModifiedFrontController() {
        $options = $this->getOption('resources');

        if ( ! isset($options['modifiedFrontController']['contentType'])) {
            return;
        }
        $this->bootstrap('FrontController');
        $front = $this->getResource('FrontController');
        //$front->addModuleDirectory(APPLICATION_PATH . '/modules');

        $response = new Zend_Controller_Response_Http;
        $response->setHeader('Content-Type',
                $options['modifiedFrontController']['contentType'], true);
        $front->setResponse($response);
    }


}