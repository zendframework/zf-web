<?php
/**
 * @package     IPMCore
 * @subpackage  Controllers
 * @author      Ernest Szulikowski <es241980@gmail.com>
 * @copyright   Ernest Szulikowski <es241980@gmail.com>
 * @version     SVN: $Id: ErrorController.php 161 2010-01-27 14:51:35Z ernie24_ernest $
 */
class ErrorController extends Zend_Controller_Action {

    public function init() {
        //$this->_helper->layout->setLayout('error');
        $this->_helper->layout->disableLayout();
    }

    public function errorAction() {
        $errors = $this->_getParam('error_handler');
        switch ($errors->type) {
            case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_ROUTE:
            case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_CONTROLLER:
            case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_ACTION:          
            // 404 error -- controller or action not found
                $this->getResponse()->setHttpResponseCode(404);
                $this->view->headTitle('Page not found', 'SET');
                $this->view->message = 'Page not found';
                $this->view->statusCode = 404;
                break;
            default:
            // application error
                if (get_class($errors->exception) == 'IPMCore_Exception') {
                    $this->getResponse()->setHttpResponseCode(500);
                    $this->view->headTitle('Internal error', 'SET');
                    $this->view->message = 'Internal error';
                    $this->view->statusCode = 500;
                } elseif ($this->getResponse()->hasExceptionOfType('Zend_Controller_Router_Exception')) {
                    $this->getResponse()->setHttpResponseCode(404);
                }
                else {
                    $this->getResponse()->setHttpResponseCode(500);
                    $this->view->headTitle('Internal error', 'SET');
                    $this->view->message = 'Internal error';
                    $this->view->statusCode = 500;
                }
                break;
        }
        $this->view->env = APPLICATION_ENV;
        $this->view->exception = $errors->exception;
        $this->view->request   = $errors->request;
    }
}


