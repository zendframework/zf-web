<?php
/**
 * @package     IPMCore
 * @subpackage  Controllers
 * @author      Ernest Szulikowski <es241980@gmail.com>
 * @copyright   Ernest Szulikowski <es241980@gmail.com>
 * @version     SVN: $Id: IndexController.php 158 2010-01-05 20:16:47Z ernie24_ernest $
 */
class IndexController extends Zend_Controller_Action {

    public function init() {
    }

    public function indexAction() {
	$this->view->test = "Hello Kittie!";
    }

}

