<?php

header('Content-type: text/plain; charset=utf-8');
require_once 'Zend/XmlRpc/Client.php';

$client = new Zend_XmlRpc_Client('http://localhost:8080/niltests/server/');

try 
{
	var_dump(
		$client->call(
			'test.nilTest',
			array (null)
		)
	);
}
catch (Exception $e)
{
	echo 'Exception: '.$e->getMessage()."\n";
}

try 
{
	var_dump(
		$client->call(
			'test.nilTest',
			array (
				array ( 'value' => 'nill', 'type' => 'nil')
			)
		)
	);
}
catch (Exception $e)
{
	echo 'Exception: '.$e->getMessage()."\n";
}

try 
{
	var_dump(
		$client->call(
			'test.nilTest',
			array (
				new Zend_XmlRpc_Value_Nil()
			)
		)
	);
}
catch (Exception $e)
{
	echo 'Exception: '.$e->getMessage()."\n";
}

try 
{
	var_dump(
		$client->call(
			'test.nilMixedTest',
			array (null)
		)
	);
}
catch (Exception $e)
{
	echo 'Exception: '.$e->getMessage()."\n";
}

try 
{
	var_dump(
		$client->call(
			'test.nilMixedTest',
			array ('string')
		)
	);
}
catch (Exception $e)
{
	echo 'Exception: '.$e->getMessage()."\n";
}

try 
{
	var_dump(
		$client->call(
			'test.nilMixedTest',
			array (12)
		)
	);
}
catch (Exception $e)
{
	echo 'Exception: '.$e->getMessage()."\n";
}

?>