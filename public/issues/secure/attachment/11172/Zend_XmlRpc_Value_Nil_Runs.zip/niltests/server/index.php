<?php

class Base64test 
{
	
	/**
	 * Nil passing test
	 *
	 * @param nil $q
	 * @return string
	 */
	public static function nilTest ( $q)
	{
		if (is_null($q))
		{
			return 'Nil passed OK';
		}
		else
		{
			return 'Nil not passed';
		}
	}
	
	/**
	 * Nil passing test
	 *
	 * @param string|nil|int $q
	 * @return string
	 */
	public static function nilMixedTest ( $q)
	{
		if (is_null($q))
		{
			return 'Nil passed OK';
		}
		else
		{
			return 'Nil not passed, but passed: '.$q.'. With type: '.gettype($q);
		}
	}
	
}

require_once 'Zend/XmlRpc/Server.php';
$server = new Zend_XmlRpc_Server();

$server->setClass('Base64test', 'test');

header('Content-type: text/xml; charset=utf-8');

echo $server->handle();

?>