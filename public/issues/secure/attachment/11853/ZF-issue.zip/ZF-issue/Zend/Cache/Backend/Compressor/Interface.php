<?php

/**
 * the compressor interface which will be used to compress javascript or css
 *
 */
interface Zend_Cache_Backend_Compressor_Interface  
{
	
	
	/**
	 * compress javascript text
	 *
	 * @param String $data
	 * @return String
	 */
	public function compressJavaScript($data);
	
	
	/**
	 * compress css text
	 *
	 * @param String $data
	 * @return String
	 */
	public function compressCss($data); 
}