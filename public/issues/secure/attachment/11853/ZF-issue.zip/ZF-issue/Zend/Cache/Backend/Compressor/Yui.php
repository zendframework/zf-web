<?php
/**
 * using compressor interface
 */
require_once 'Zend/Cache/Backend/Compressor/Interface.php';

/**
 * @package Zend_Cache
 * using Yui_Compressor to implement the functionality which compresses js/css 
 * need to install jre/jdk firstly, and java command need to use in the system
 */
class Zend_Cache_Backend_Compressor_Yui implements Zend_Cache_Backend_Compressor_Interface 
{

	public $jarFile = '';//dirname(__FILE__) .'/assets/yuicompressor-2.4.2.jar';
    
    /**
     * Writable temp directory. This must be set before calling minifyJs()
     * or minifyCss().
     *
     * @var string
     */
    public $tempDir = null;
    
    /**
     * Filepath of "java" executable (may be needed if not in shell's PATH)
     *
     * @var string
     */
    public $javaExecutable = 'java';
    
    public $options = array();
     
    public function __construct() 
    {
    	
    	$this->jarFile = dirname(__FILE__) .'/assets/yuicompressor-2.4.2.jar';
    	
    	if (function_exists('sys_get_temp_dir')) {
    		$this->tempDir = sys_get_temp_dir();
    	} else {
    		$this->tempDir = $this->_getTempDir();
    	}
    }
    
	public function compressJavaScript($buffer) 
	{
		 return $this->_minify('js', $buffer, $this->options);
	}
	
	public function compressCss($buffer) 
	{
	     return $this->_minify('css', $buffer, $this->options);
	}
	
	private function _getTempDir() 
	{
		
	    if (!empty($_ENV['TMP'])) { return realpath($_ENV['TMP']); }
	    if (!empty($_ENV['TMPDIR'])) { return realpath( $_ENV['TMPDIR']); }
	    if (!empty($_ENV['TEMP'])) { return realpath( $_ENV['TEMP']); }
	    $tempfile = tempnam(uniqid(rand(),TRUE),'');
	    if (file_exists($tempfile)) {
	   		unlink($tempfile);
	    	return realpath(dirname($tempfile));
	    }
	}

 	private function _minify($type, $content, $options) 
 	{
        $this->_prepare();
        if (! ($tmpFile = tempnam($this->tempDir, 'yuic_'))) {
            throw new Exception('Minify_YUICompressor : could not create temp file.');
        }
        file_put_contents($tmpFile, $content);
        
        $cmd = $this->_getCmd($options, $type, $tmpFile);
        exec($cmd, $output);
        unlink($tmpFile);
        return implode("\n", $output);
    }
    
	private function _getCmd($userOptions, $type, $tmpFile) 
	{
        $o = array_merge(
            array(
                'charset' => '',
                'line-break' => 5000,
                'type' => $type,
                'nomunge' => false,
                'preserve-semi' => false,
                'disable-optimizations' => false
            ),
            $userOptions
        );
        $cmd = $this->javaExecutable . ' -jar ' . escapeshellarg($this->jarFile)
             . " --type {$type}"
             . (preg_match('/^[a-zA-Z\\-]+$/', $o['charset']) 
                ? " --charset {$o['charset']}" 
                : '')
             . (is_numeric($o['line-break']) && $o['line-break'] >= 0
                ? ' --line-break ' . (int)$o['line-break']
                : '');
        if ($type === 'js') {
            foreach (array('nomunge', 'preserve-semi', 'disable-optimizations') as $opt) {
                $cmd .= $o[$opt] 
                    ? " --{$opt}"
                    : '';
            }
        }
        return $cmd . ' ' . escapeshellarg($tmpFile);
    }
    
 	private function _prepare() 
 	{
        if (! is_file($this->jarFile) 
            || ! is_dir($this->tempDir)
            || ! is_writable($this->tempDir)
        ) {
            throw new Exception('Yui compressor : $jarFile and $tempDir must be set.');
        }
    }
}