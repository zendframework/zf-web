<?php

require_once 'Zend/Cache/Backend/Compressor/Interface.php';

/**
 * using JSMin packer to compress javascript text
 */
require_once dirname(__FILE__) . '/assets/JSMin.php';

/**
 * using JSMin packer to compress javascript text
 */
require_once dirname(__FILE__) . '/assets/Minify_CSS.php';

/**
 * compress js level
 */
define('JS_COMPRESS_LEVEL','None');

class Zend_Cache_Backend_Compressor_Jsmin implements Zend_Cache_Backend_Compressor_Interface 
{
	
	
	public function compressJavaScript($buffer) 
	{
		return JSMin::minify($buffer);
	}
	
	public function compressCss($buffer) 
	{
	    return Minify_CSS::minify($buffer);
	}
	
}