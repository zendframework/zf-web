<?php

require_once 'Zend/Cache/Backend/Compressor/Interface.php';

/**
 * using JavaScriptPacker to compress javascript text
 */
require_once dirname(__FILE__) . '/assets/JavaScriptPacker.php';

/**
 * compress js level
 * 
 * @see JavaScriptPacker
 */
define('JS_COMPRESS_LEVEL','None');

/**
 * @package Zend_Cache
 * 
 * default compressor using JavaScriptPakcer
 * 
 **/
class Zend_Cache_Backend_Compressor_Default implements Zend_Cache_Backend_Compressor_Interface 
{
	
	public function compressJavaScript($buffer) 
	{
		$myPacker = new JavaScriptPacker($buffer, JS_COMPRESS_LEVEL, false, false);
		return $myPacker->pack();
	}
	
	public function compressCss($buffer) 
	{
	    // remove comments
	    $buffer = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $buffer);
	    // remove tabs, spaces, newlines, etc.
	    $buffer = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $buffer);
	    return $buffer;
	}
	
}