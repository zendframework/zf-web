<?php

/**
 * @author robbin <robbin.joe@gmail.com>
 * @package Zend_Cache
 * @version 1.0
 *
 */
class Zend_Cache_Backend_Compression extends Zend_Cache_Backend_File
{
	private $types  = array('css','js');
	private $prefix = 'Zend_Cache_Backend_Compressor_';
	
	/**
	 * the instance of Zend_Cache_Backend_Compressor_Interface
	 *
	 * @var Zend_Cache_Backend_Compressor_Interface
	 */
	private $compressor ;
	
	protected $_options = array(
        'cache_dir' => null,
        'file_locking' => true,
        'read_control' => true,
        'read_control_type' => 'crc32',
        'hashed_directory_level' => 0,
        'hashed_directory_umask' => 0700,
        'file_name_prefix' => 'zend_cache',
        'cache_file_umask' => 0600,
        'metadatas_array_max_size' => 100,
        
        /**
         * enable gz_deflate compressor
         */
        'gz_enable' => false,
        
        /**
         * valid candidate 'default', 'jsmin' , 'yui'
         */
        'compressor' => 'default'
    );
    
    public function __construct($options = array()) 
    {
    	parent::__construct($options);
    	
    	$class 	= $this->prefix . ucfirst(strtolower($this->_options['compressor']));
    	Zend_Loader::loadClass($class);    	
    	$this->compressor = new $class();
    }
	
    /**
     * override save method to deal with the data using compressor
     */
	public function save($data, $id, $tags = array(), $specificLifetime = false) 
	{
    	
		if ($type = array_intersect($this->types, $tags)) {
			//compress 			
    		$method = 'compress'. ucfirst(array_shift($type));
    		$data   = $this->$method($data);    		
    	}
    	
    	if ($this->_options['gz_enable']) {
    		$data = gzdeflate($data);
    		
    		/** the better way to http protecol
    		//set http header content-encoding
				if(strstr($_SERVER["HTTP_ACCEPT_ENCODING"],"gzip")) {
					header("Content-Encoding: gzip");
					$data = gzencode($data);
				} else {
					header("Content-Encoding: deflate");
					$data = gzdeflate($data);
	    		}
			*/
    	}
    	return parent::save($data, $id, $tags, $specificLifetime);
    }
    
    private function compressJs($data) 
    {
    	return $this->compressor->compressJavaScript($data);
    }
    
    private function compressCss($data) 
    {
    	return $this->compressor->compressCss($data);
    }
}
