<?php

header("Content-type: text/plain");
ini_set("display_errors", "1");
require_once("Zend/Translate.php");
$translate = new Zend_Translate("csv", "translation.csv", "en", array('separator' => ';'));
echo $translate->_("FOO1");

?>