<?php

/**
 * You have to make one additional request before try to validate captcha form.
 * Because i'm making requests to framework for css and js files.
 * So you have to make 2 files. First open the file where the form is. The open
 * the other file where only session is started. Then try to submit the form. It
 * is not working see my comments below.
 */

class Test_CaptchaForm extends Zend_Form 
{
    
    public function init()
    {
        
        $captcha = new Zend_Captcha_Image();
        $captcha->setFont(Xpucmo_Main::getPath('resources', array('fonts', 'verdana.ttf')));
        $captcha->setImgDir(Xpucmo_Main::getPath('wwwStatic', array('images', 'captcha')));
        $captcha->setImgUrl(Zend_Registry::get('Config_Common')->host->static.'/images/captcha/');
        $captcha->setWidth(150);
        $captcha->setHeight(75);
        $captcha->setWordlen(6);

        /** 
         * When i do this here expiration hops are not set to right session namespace
         * See dump first session dump
         */
        $captcha->getSession()->setExpirationHops(6, null, true);
        
        Zend_Debug::dump($_SESSION);
        
        $elementCaptcha = new Zend_Form_Element_Captcha(
            'captcha', array('captcha' => $captcha)
        );
            $elementCaptcha->setLabel('captcha');

        $elementSubmit = new Zend_Form_Element_Submit('doSubmit');

        $this->addElements(array(
            $elementCaptcha, $elementSubmit
        ));
        
    }
    
    public function render(Zend_View_Interface $view = null)
    {
        $content = parent::render($view);

        /**
         * Look here the session namespace for captcha is changed.
         */
        Zend_Debug::dump($_SESSION);

        /**
         * So i'm trying to explain that when i try to set expiration hops before 
         * captcha is rendered then it is not working. But when i do this after form
         * is rendere everything is working fine.
         */
        
        return $content;
    }    
    
}