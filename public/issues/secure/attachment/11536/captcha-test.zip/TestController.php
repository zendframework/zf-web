<?php 

class TestController extends Zend_Controller_Action 
{
    
    public function captchaFormAction()
    {
        $form = new Test_CaptchaForm();

        $this->view->validForm = null;
        
        if (Xpucmo_Main::buttonPresses('doSubmit')) {
            if ($form->isValid($_POST)) {
                $this->view->validForm = true;
            } else {
                $this->view->validForm = false;
            }
        }
        
        $this->view->form = $form;
    }
    
}