<?php
$pdf = new Zend_Pdf();
$pdf->pages[] = $page = new Zend_Pdf_Page(Zend_Pdf_Page::SIZE_A4);
$page->drawImage(Zend_Pdf_Image::imageWithPath('test.jpg'), 25, 600, 275, 800);
$pdf->save('test.pdf');