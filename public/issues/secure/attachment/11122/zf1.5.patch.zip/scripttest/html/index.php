<?php
/**
 * My new Zend Framework project
 * 
 * @author  
 * @version 
 */

require_once '../library/bootstrap.php';
