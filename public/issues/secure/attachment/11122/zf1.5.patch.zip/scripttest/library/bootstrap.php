<?php
set_include_path('.' . PATH_SEPARATOR . '../library' 
                    . PATH_SEPARATOR . './application/default/models/' 
                    . PATH_SEPARATOR . './application/default/controllers/'
                    . PATH_SEPARATOR . get_include_path());
require_once 'Zend/Controller/Front.php';
require_once 'Zend/Loader.php';
require_once 'Zend/Layout.php';
require_once 'Zend/Controller/Action.php';

/**
 * Setup controller
 */
Zend_Layout::startMvc();

$controller = Zend_Controller_Front::getInstance();
$controller->setBaseUrl('');
$controller->setParam('basePath',dirname(__FILE__));
$controller->setParam('htmlPath',dirname(__FILE__).DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'html');
$controller->setParam('scriptsMapppers', array( 
										'fs' => $controller->getParam("htmlPath").DIRECTORY_SEPARATOR.'scripts' 
										,'url' => $controller->getBaseUrl().'/scripts' 
										));
$controller->setParam('stylesMapppers', array( 
										'fs' => $controller->getParam("htmlPath").DIRECTORY_SEPARATOR.'styles' 
										,'url' => $controller->getBaseUrl().'/styles' 
										));
								
										
$controller->setControllerDirectory('../application/default/controllers');
$controller->throwExceptions(false); // should be turned on in development time 
// run!
$controller->dispatch();