<?php

/**
 * IndexController - The default controller class
 * 
 * @author
 * @version 
 */

require_once 'Zend/Controller/Action.php';

class IndexController extends Zend_Controller_Action 
{
	/**
	 * The default action - show the home page
	 */
    public function indexAction() 
    {
		$this->view->headScript()->appendFile('pippo.js');
		$this->view->headScript()->appendFile($this->_getParam('controller').'.js');
		$this->view->headScript()->appendFile($this->_getParam('controller').'_'.$this->_getParam('action').'.js');

    }
}
