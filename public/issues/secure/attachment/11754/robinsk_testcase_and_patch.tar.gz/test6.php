<?php
require './Zend/Config.php';

$data = array(
    'first'  => 1,
    'second' => 2,
    'third'  => 3,
    'fourth' => 4
);

echo 'Data:', PHP_EOL;
print_r($data);

echo <<<EOT

Test:
Iterate the config two times, with two separate for loops.
Unset 'fourth' during first iteration.
Unset 'second' between iterations.
Unset 'third' during second iteration.

Expected output:
----------------
first
second
third
fourth
 - unset
Count: 3
first
third
 - unset
Count: 1

Actual output:
--------------

EOT;

$config = new Zend_Config($data, true);
foreach ($config as $key => $value) {
    echo $key, PHP_EOL;
    if ($key == 'fourth') {
        echo ' - unset', PHP_EOL;
        unset($config->$key);
    }
}

unset($config->second);

foreach ($config as $key => $value) {
    echo $key, PHP_EOL;
    if ($key == 'third') {
        echo ' - unset', PHP_EOL;
        unset($config->$key);
    }
}

echo 'Count: ', count($config), PHP_EOL;

