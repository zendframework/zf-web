<?php
require './Zend/Config.php';

$data = array(
    'first'  => 1,
    'second' => 2,
    'third'  => 3,
    'fourth' => 4
);

echo 'Data:', PHP_EOL;
print_r($data);

echo <<<EOT

Test:
Unset the 'first' key before iterating.

Expected output:
----------------
second
third
fourth
Count: 3

Actual output:
--------------

EOT;

$config = new Zend_Config($data, true);
unset($config->first);
foreach ($config as $key => $value) {
    echo $key, PHP_EOL;
}

echo 'Count: ', count($config), PHP_EOL;

