<?php
require './Zend/Config.php';

$data = array(
    'first'  => 1,
    'second' => 2,
    'third'  => 3,
    'fourth' => 4
);

echo 'Data:', PHP_EOL;
print_r($data);

echo <<<EOT

Test:
Unset the 'second' key before iterating, and unset 'third' when iterating.

Expected output:
----------------
first
third
 - unset
fourth
Count: 2

Actual output:
--------------

EOT;

$config = new Zend_Config($data, true);
unset($config->second);
foreach ($config as $key => $value) {
    echo $key, PHP_EOL;
    if ($key == 'third') {
        echo ' - unset', PHP_EOL;
        unset($config->$key);
    }
}

echo 'Count: ', count($config), PHP_EOL;

