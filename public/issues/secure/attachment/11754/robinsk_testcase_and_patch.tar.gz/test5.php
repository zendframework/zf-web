<?php
require './Zend/Config.php';

$data = array(
    'first'  => 1,
    'second' => 2,
    'third'  => 3,
    'fourth' => 4
);

echo 'Data:', PHP_EOL;
print_r($data);

echo <<<EOT

Test:
Iterate the config two times, with two separate for loops.
Unset 'first' during first iteration. Unset 'third' during second iteration.

Expected output:
----------------
first
 - unset
second
third
fourth
Count: 3
second
third
 - unset
fourth
Count: 2

Actual output:
--------------

EOT;

$config = new Zend_Config($data, true);
foreach ($config as $key => $value) {
    echo $key, PHP_EOL;
    if ($key == 'first') {
        echo ' - unset', PHP_EOL;
        unset($config->$key);
    }
}

foreach ($config as $key => $value) {
    echo $key, PHP_EOL;
    if ($key == 'third') {
        echo ' - unset', PHP_EOL;
        unset($config->$key);
    }
}

echo 'Count: ', count($config), PHP_EOL;

