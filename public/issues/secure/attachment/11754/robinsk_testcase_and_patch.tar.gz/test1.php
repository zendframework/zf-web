<?php
require './Zend/Config.php';

$data = array(
    'first'  => 1,
    'second' => 2,
    'third'  => 3,
    'fourth' => 4
);

echo 'Data:', PHP_EOL;
print_r($data);

echo <<<EOT

Test:
Unset the 'second' key during iteration.

Expected output:
----------------
first
second
 - unset
third
fourth
Count: 3

Actual output:
--------------

EOT;

$config = new Zend_Config($data, true);
foreach ($config as $key => $value) {
    echo $key, PHP_EOL;
    if ($key == 'second') {
        echo ' - unset', PHP_EOL;
        unset($config->$key);
    }
}

echo 'Count: ', count($config), PHP_EOL;

