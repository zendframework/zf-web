<?php

// program for proving and fixing the Zend Framework 1.7.8
// Zend_Gdata_Photos lookupNamespace() performance issue
// Email: coder@paul-mitchell.me.uk
// MSN: paulmitchell2112@hotmail.com

$testObj = new stdClass;

$testObj->userFeed =
    new Zend_Gdata_Photos_UserFeed(
        DOMDocument::load( 'data/libertus96.atom.xml' )->documentElement
    )
;

for( $index = 1; $index <= 4; $index++ )
{
    $testObj->albumFeeds[] =
        new Zend_Gdata_Photos_AlbumFeed(
            DOMDocument::load( "data/album_$index.atom.xml" )->documentElement
        )
    ;
}

echo 'MD5 checksum = '.md5(serialize($testObj))."\n";
