<?php

$path = 'library-1.6RC1/';
set_include_path($path . PATH_SEPARATOR  . get_include_path());

require_once 'Zend/Search/Lucene.php';

/*
* path to lucene collection directory
*/
$collection_path = 'collections/IndexSource/data/text';
$queryField = '_plain';
$queryStr = 'test';

$index = new Zend_Search_Lucene($collection_path);

echo "Index contains " . $index->numDocs() . " documents.<br>";


/*
* dump the field names
*/
$fieldnames = $index->getFieldNames(true);
//sort($fieldnames);
echo "<p>Index contains " . count($fieldnames) . " field names.<br>";
echo '<ul>';
foreach ($fieldnames as $name) {
  echo '<li>' . $name . '</li>';
}
echo '</ul>';




/*
* set the search field
*/
$index->setDefaultSearchField($queryField);

/*
* build the query
*/
$query = Zend_Search_Lucene_Search_QueryParser::parse($queryStr, 'UTF-8');

/*
* perform the search and dump results
*/
$hits   = $index->find($query);
echo "<p>Search for \"$query\" returned " .count($hits). " hits.<br>";
echo '<ul>';
foreach ($hits as $hit) {
  echo '<li>' . 'ID: ' . $hit->id . ' Score: ' . sprintf('%.2f', $hit->score) . ' ' . $hit->uri .'</li>';
}
echo '</ul>';


/*
* dump the indexed terms
*/
// $terms = $index->terms();
// echo "<p>Index contains " . count($terms) . " terms.";
// echo '<table border=1><tr><td>Field</td><td>Text</td><td></td></tr>';
// foreach ($terms as $term) {
//   echo '<tr><td>' . $term->field . '</td><td>' . $term->text . '</td></tr>';
// }
// echo "</table>";

