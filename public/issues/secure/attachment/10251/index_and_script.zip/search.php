<?php
/**
 * $Id$
 */

error_reporting(E_ALL|E_STRICT);
ini_set('display_errors', '1');

set_include_path(
	'.'
	// . PATH_SEPARATOR . './library/ZendFramework-0.7.0/library'
	// . PATH_SEPARATOR . './library/ZendFramework-0.7.0/incubator'
	. PATH_SEPARATOR . './library/ZendFramework-trunk/library'
	. PATH_SEPARATOR . './library/ZendFramework-trunk/incubator'
);

function __autoload($classname) {
    @include(str_replace('_', '/', $classname).'.php');
}

function benchmarkTime($startTime, $endTime) {
    $startTime = explode(' ',$startTime);
    $startTime = $startTime[1] + $startTime[0];
    $endTime = explode(' ', $endTime);
    $endTime = $endTime[1] + $endTime[0];
    return ($endTime - $startTime);
}

try {
    
    $startTime = microtime();
    $index = new Zend_Search_Lucene('./indexer/index4515');
    echo 'Open: '.benchmarkTime($startTime, microtime())."\n";
    
    $startTime = microtime();
    $hits = $index->find('Sommer T�rkei');
    echo 'Search: '.benchmarkTime($startTime, microtime())."\n";
    
    $startTime = microtime();
    foreach ($hits as $hit) {
        echo round($hit->score, 5).' : ';
        echo $hit->filename."\n";
    }
    echo 'Output: '.benchmarkTime($startTime, microtime())."\n";
    
} catch (Exception $e) {
    echo $e->__toString();
}
