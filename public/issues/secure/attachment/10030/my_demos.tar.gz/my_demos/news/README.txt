This is the only real-world Web based demo for ZF I found so far!

See:
http://hades.phparch.com/ceres/public/article/index.php/art::zend_framework::tutorial

It's pretty good I think, although it does have a minor big in the admin page, the dir layout is non-standard, and I further complicated that by creating a 'db' directory, and an 'app/lib' dir because I didn't know where else to put it in a portable demo. As for the 'model' part of MVC, hey, I'm a newbie still.

Mark Maynereid
5th July 2006