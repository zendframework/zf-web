<?php

class Database
{
    private $_db;

    public function __construct($filename)
    {
		// I added an auto-table create feature in the event the db does not already exist, mim 3/7/06
		$is_create_tables = false;
		if (!is_file($filename)) {
			trigger_error('Database file missing will try and create it');
			$is_create_tables = true;
		}
        $this->_db = new SQLiteDatabase($filename);
		if ($is_create_tables) {
			$this->_db->query("CREATE TABLE news (
				id       INTEGER PRIMARY KEY,
				title    VARCHAR(255),
				content  TEXT,
				approval CHAR(1) DEFAULT 'F'
			)");
			$this->_db->query("CREATE TABLE comments (
				id       INTEGER PRIMARY KEY,
				name     VARCHAR(255),
				comment  TEXT,
				newsId   INTEGER
			)");
		}
    }

    public function addComment($name, $comment, $newsId)
    {
        $name = sqlite_escape_string($name);
        $comment = sqlite_escape_string($comment);
        $newsId = sqlite_escape_string($newsId);

        $sql = "INSERT
                INTO   comments (name, comment, newsId)
                VALUES ('$name', '$comment', '$newsId')";

        return $this->_db->query($sql);
    }

    public function addNews($title, $content)
    {
        $title = sqlite_escape_string($title);
        $content = sqlite_escape_string($content);

        $sql = "INSERT
                INTO   news (title, content)
                VALUES ('$title', '$content')";

        return $this->_db->query($sql);
    }

    public function approveNews($ids)
    {
        foreach ($ids as $id) {
            $id = sqlite_escape_string($id);

            $sql = "UPDATE news
                    SET    approval = 'T'
                    WHERE  id = '$id'";

            if (!$this->_db->query($sql)) {
                return FALSE;
            }
        }

        return TRUE;
    }

    public function getComments($newsId)
    {
        $newsId = sqlite_escape_string($newsId);

        $sql = "SELECT name, comment
                FROM   comments
                WHERE  newsId = '$newsId'";

        if ($result = $this->_db->query($sql)) {
            return $result->fetchAll();
        }

        return FALSE;
    }

    public function getNews($id = 'ALL')
    {
        $id = sqlite_escape_string($id);

        switch ($id) {
            case 'ALL':
                $sql = "SELECT id,
                               title
                        FROM   news
                        WHERE  approval = 'T'";
                break;
            case 'NEW':
                $sql = "SELECT *
                        FROM   news
                        WHERE  approval != 'T'";
                break;
            default:
                $sql = "SELECT *
                        FROM   news
                        WHERE  id = '$id'";
                break;
        }

        if ($result = $this->_db->query($sql)) {
            if ($result->numRows() != 1) {
                return $result->fetchAll();
            } else {
                return $result->fetch();
            }
        }

        return FALSE;
    }
}

?>
