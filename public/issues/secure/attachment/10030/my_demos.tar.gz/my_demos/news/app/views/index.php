<html>
<head>
  <title>News</title>
</head>
<body>
  <h1>News</h1>
  <?php foreach ($this->news as $entry) { ?>
  <p>
    <a href="<?php echo $this->baseUrl; ?>/view/<?php echo $this->escape($entry['id']); ?>">
    <?php echo $this->escape($entry['title']); ?>
    </a>
  </p>
  <?php } ?>
  <h1>Add News</h1>
  <form action="<?php echo $this->baseUrl; ?>/add/news" method="POST">
  <p>Title:<br /><input type="text" name="title" /></p>
  <p>Content:<br /><textarea name="content"></textarea></p>
  <p><input type="submit" value="Add News" /></p>
  </form>

<p>See the online <a href="http://hades.phparch.com/ceres/public/article/index.php/art::zend_framework::tutorial" target="_blank">tutorial</a> for more info.</p>

<p>Here is a link to the <a href="<?php echo $this->baseUrl; ?>/admin">AdminController</a> which lets you approve new news items you submitted here.</p>

<p>Return to my intranet <a href="/">home page</a></p>
</body>
</html>
