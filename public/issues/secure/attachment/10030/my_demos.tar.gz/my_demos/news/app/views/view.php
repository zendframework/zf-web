<html>
<head>
  <title>
    <?php echo $this->escape($this->news['title']); ?>
  </title>
</head>
<body>
  <h1>
    <?php echo $this->escape($this->news['title']); ?>
  </h1>
  <p>
    <?php echo $this->escape($this->news['content']); ?>
  </p>
  <h1>Comments</h1>
  <?php foreach ($this->comments as $comment) { ?>
  <p>
    <?php echo $this->escape($comment['name']); ?> writes:
  </p>
  <blockquote>
    <?php echo $this->escape($comment['comment']); ?>
  </blockquote>
  <?php } ?>
  <h1>Add a Comment</h1>
  <form action="<?php echo $this->baseUrl; ?>/add/comment" method="POST">
  <input type="hidden" name="newsId" 
    value="<?php echo $this->escape($this->id); ?>" />
  <p>Name:<br /><input type="text" name="name" /></p>
  <p>Comment:<br /><textarea name="comment"></textarea></p>
  <p><input type="submit" value="Add Comment" /></p>
  </form>

  <p><a href="<?php echo $this->baseUrl; ?>/">Home page</a></p>
</body>
</html>
