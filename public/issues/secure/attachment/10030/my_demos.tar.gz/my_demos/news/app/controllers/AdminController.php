<?php

class AdminController extends Zend_Controller_Action
{
    function indexAction()
    {
        /* Display admin interface. */
        $db = Zend::registry('db');
        $view = Zend::registry('view');
        $view->baseUrl = Zend::registry('controller')->getRouter()->getRewriteBase();
        $view->news = $db->getNews('NEW');
        echo $view->render('admin.php');
    }

    function approveAction()
    {
        /* Approve news. */
        $filterPost = new Zend_Filter_Input($_POST);
        $db = Zend::registry('db');
        if ($filterPost->getRaw('password') == 'mypass') {
            $db->approveNews($filterPost->getRaw('ids'));
            $baseUrl = Zend::registry('controller')->getRouter()->getRewriteBase();
            $this->_redirect($baseUrl.'/');
        } else {
            echo 'The password is incorrect.';
        }
    }

    function __call($action, $arguments)
    {
        $baseUrl = Zend::registry('controller')->getRouter()->getRewriteBase();
        $this->_redirect($baseUrl.'/');
    }
}

?>
