<?php

class AddController extends Zend_Controller_Action
{
    function indexAction()
    {
        $baseUrl = Zend::registry('controller')->getRouter()->getRewriteBase();
        $this->_redirect($baseUrl.'/');
    }

    function commentAction()
    {
        /* Add a comment. */
        $filterPost = new Zend_Filter_Input($_POST);
        $db = Zend::registry('db');
        $name = $filterPost->getAlpha('name');
        $comment = $filterPost->noTags('comment');
        $newsId = $filterPost->getDigits('newsId');
        $db->addComment($name, $comment, $newsId);
        $baseUrl = Zend::registry('controller')->getRouter()->getRewriteBase();
        $this->_redirect("$baseUrl/view/$newsId");
    }

    function newsAction()
    {
        /* Add news. */
        $filterPost = new Zend_Filter_Input($_POST);
        $db = Zend::registry('db');
        $title = $filterPost->noTags('title');
        $content = $filterPost->noTags('content');
        $db->addNews($title, $content);
        $baseUrl = Zend::registry('controller')->getRouter()->getRewriteBase();
        $this->_redirect($baseUrl.'/');
    }

    function __call($action, $arguments)
    {
        $baseUrl = Zend::registry('controller')->getRouter()->getRewriteBase();
        $this->_redirect($baseUrl.'/');
    }
}

?>
