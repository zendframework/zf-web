<html>
<head>
  <title>News Admin</title>
</head>
<body>
  <form action="<?php echo $this->baseUrl; ?>/admin/approve" method="POST">
  <?php foreach ($this->news as $entry) { ?>
  <p>
    <input type="checkbox" name="ids[]"
    value="<?php echo $this->escape($entry['id']); ?>" />
    <?php echo $this->escape($entry['title']); ?>
    <?php echo $this->escape($entry['content']); ?>
  </p>
  <?php } ?>
  <p>
    Password ('mypass'):<br /><input type="password" name="password" />
  </p>
  <p><input type="submit" value="Approve" /></p>
  </form>
    <p>
        Note. This is demo is from <a href="http://hades.phparch.com/ceres/public/article/index.php/art::zend_framework::tutorial"> Chris Shiflett's tutorial</a>, but it seems to have a bug in it, as the Databse.php class he provides returns differing result set formats which, when there is only one result, the foreach loop in this view page (admin.php) screws up. Not a showstopper to use it but ugly when only one entry. Here's a vardump:
    </p>
	<pre>
	<?php var_dump($this->news); ?>
	</pre>

  <p><a href="<?php echo $this->baseUrl; ?>/">Home page</a></p>

</body>
</html>
