<?php

class ViewController extends Zend_Controller_Action
{
    function indexAction()
    {
        $baseUrl = Zend::registry('controller')->getRouter()->getRewriteBase();
        $this->_redirect($baseUrl.'/');
    }

    function __call($id, $arguments)
    {
        /* Display news and comments for $id. */
        $id = Zend_Filter::getDigits($id);
        $db = Zend::registry('db');
        $view = Zend::registry('view');

        $view->baseUrl = Zend::registry('controller')->getRouter()->getRewriteBase();

        $view->news = $db->getNews($id);
        $view->comments = $db->getComments($id);
        $view->id = $id;
        echo $view->render('view.php');
    }
}

?>
