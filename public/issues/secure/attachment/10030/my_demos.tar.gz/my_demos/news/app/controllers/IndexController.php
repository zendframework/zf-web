<?php

class IndexController extends Zend_Controller_Action 
{
    public function indexAction()
    {
        /* List the news. */
        $db = Zend::registry('db');
        $view = Zend::registry('view');
        $view->baseUrl = Zend::registry('controller')->getRouter()->getRewriteBase();
        $view->news = $db->getNews();
        echo $view->render('index.php');
    }

    public function noRouteAction()
    {
        $baseUrl = Zend::registry('controller')->getRouter()->getRewriteBase();
        $this->_redirect($baseUrl.'/');
    }
}

?>
