Zend Framework demos in subdirs!
--------------------------------

This directory contains Web based, portable, Zend Framework demos I found on the Net and made work in any subdir below docroot!

IMPORTANT - Modify .htaccess in this directory

To make the demos work in subdirs below docroot, I first put my own quick'n'dirty fix in, but have since replaced this after discovering the RewriteRouter in the incubator of ZendFramework-0.1.4 which addresses this very issue!

The only pain I found in modifying the demos was, every internal link in a demo needs prepending with the baseUrl value and causes a bit of code clutter to bring the value in where needed.

In the index.php file I took the following approach:

// Register the controller because it is the only way I know to get at the RewriteRouter's GetRewriteBase() method from within my controllers
Zend::register('controller', $controller);

// Use the new RewriteRouter from the incubator (ZendFramework-0.1.4) which allows us to run demos in subdirs below the webserver's docroot.
require_once 'Zend/Controller/RewriteRouter.php';
$router = new Zend_Controller_RewriteRouter();
$controller->setRouter($router);

$controller->dispatch();


I then access the baseUrl value in my controllers with (or similar):
$baseUrl = Zend::registry('controller')->getRouter()->getRewriteBase();

Is there a better way?

Mark Maynereid
5th July 2006

P.S.

This subdir below docroot feature is common amongst other frameworks. I've looked at plenty, and my interest in ZF nearly timed out when I found this wasn't supported already.

Surely, for a framework to gain and sustain popularity, you need to showcase what it can do with a whole bunch of 'real-world' ready-to-run demos? I know it's early days for ZF but still! I guess also, there should be some QA on them, before you know it ZF morphs into a CMS, errr... perhaps I shouldn't have said that.