<?php
require_once 'Zend/Controller/Front.php';

$controller = Zend_Controller_Front::getInstance();
$controller->setControllerDirectory('../application/controllers');

// Register the controller because it is the only way I know to get at the RewriteRouter's GetRewriteBase() method from within my controllers
Zend::register('controller', $controller);

// Use the new RewriteRouter from the incubator (ZendFramework-0.1.4) which allows us to run demos in subdirs under the webserver's docroot.
require_once 'Zend/Controller/RewriteRouter.php';
$router = new Zend_Controller_RewriteRouter();
$controller->setRouter($router);

$controller->dispatch();

?>
