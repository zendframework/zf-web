<?php
require_once 'Zend/Controller/Action.php';

class IndexController extends Zend_Controller_Action 
{
	public function indexAction()
	{
		echo 'Hello from IndexController';
	}

	public function noRouteAction()
	{
        $baseUrl = Zend::registry('controller')->getRouter()->getRewriteBase();
		$this->_redirect($baseUrl.'/');
	}
}

?>