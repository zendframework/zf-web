<?php
class ErrorController extends Zend_Controller_Action
{
    public function errorAction(){
        $this->getResponse()->clearBody();
        require_once 'Zend/Log.php';
        require_once 'Zend/Log/Writer/Stream.php';
        $logger = new Zend_Log();
        $error = Zend_Controller_Action::_getParam('error_handler');
        $errorMsg = $error->exception->getMessage();
        try{
            $writer = new Zend_Log_Writer_Stream('Logs/logfile');
            $logger->addWriter($writer);
            $logger->log($this->getRequest()->getRequestUri().' '.$errorMsg, Zend_Log::ERR);
            $this->view->errorMsg = $errorMsg;
        }
        catch (Zend_Exception $e){
            $this->view->errorMsg = 'oopsie, problem with writing log files ... WTF ?';
        }
    }
}
?>