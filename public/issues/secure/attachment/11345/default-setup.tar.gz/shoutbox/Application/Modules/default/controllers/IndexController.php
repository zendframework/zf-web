<?php
class IndexController extends Zend_Controller_Action
{
	function preDispatch(){
		parent::preDispatch();
	}
	
	function init(){
		parent::init();
	}
	
	function postDispatch(){
		parent::postDispatch();
	}
	
	function indexAction(){
		
	}
}
?>