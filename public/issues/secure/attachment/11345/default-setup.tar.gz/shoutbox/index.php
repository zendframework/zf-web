<?php
$xstart = microtime(true);
// DO NOT TOUCH
set_include_path('.' . PATH_SEPARATOR . './Library/'
. PATH_SEPARATOR . './Application/'
. PATH_SEPARATOR . get_include_path());
//shut down magic quotes
if (get_magic_quotes_gpc()) {
	function cb_stripslashes(&$value, $key) {
		$value = stripslashes($value);
	}
	array_walk_recursive($_GET, 'cb_stripslashes');
	array_walk_recursive($_POST, 'cb_stripslashes');
	array_walk_recursive($_COOKIE, 'cb_stripslashes');
	array_walk_recursive($_REQUEST, 'cb_stripslashes');
}
//configuration
require 'Zend/Config/Ini.php';
$config = new Zend_Config_Ini('./Application/config.ini','site');
//default date
date_default_timezone_set($config->setup->defaultTimezone);
//registry
require 'Zend/Registry.php';
Zend_Registry::set('config',$config);
//error handling
if($config->setup->debug){
	error_reporting(E_ALL);
}
else{
	error_reporting(0);
}
//cache
require 'Zend/Cache.php';
$cache = Zend_Cache::factory('Core', $config->setup->cache->type , $config->setup->cache->frontendOptions->toArray(), $config->setup->cache->backendOptions->toArray());
Zend_Registry::set('cache',$cache);
//front controller
require 'Zend/Controller/Front.php';
$frontController = Zend_Controller_Front::getInstance();
$frontController->addModuleDirectory($config->setup->frontController->moduleDirectory);
/*
$router = $frontController->getRouter();
$router->addConfig($config->router,'routes');
$frontController->setRouter($router);
*/
//zend layout
require 'Zend/Layout.php';
Zend_Layout::startMvc($config->setup->layout->toArray());
//dispatch
$frontController->dispatch();
//additional debug

if($config->setup->debug == true){
	if(class_exists('Zend_Db_Table') && Zend_Db_Table::getDefaultAdapter() && $config->setup->database->profiler == true){
		$profiler = Zend_Db_Table::getDefaultAdapter()->getProfiler();
		$queries = $profiler->getQueryProfiles(Zend_Db_Profiler::SELECT | Zend_Db_Profiler::INSERT | Zend_Db_Profiler::UPDATE | Zend_Db_Profiler::DELETE | Zend_Db_Profiler::TRANSACTION);
		$i=0;
		if(!empty($queries)){
			foreach($queries as $query){
				echo '<div class="debugQuery">'. ++$i.'. '. $query->getQuery() . '</div>';
			}
		}
		echo '' . substr((microtime(true)-$xstart),0,5) . '| queries: '. $profiler->getTotalNumQueries() .'| total query time : '.substr($profiler->getTotalElapsedSecs(),0,5).'s';
	}
	else{
		echo '' . substr((microtime(true)-$xstart),0,5) . 's';
	}
}
?>