<?php

class ARemoteClass {
	var $i;
}