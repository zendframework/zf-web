<?php
include 'ARemoteClass.php'; 

class  Srv {
	
	public function test(ARemoteClass $a)
	{
		return $a;
	}


}