<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
    /**
     * 
     * Initializes the Core module routes
     * @var Zend_Application_Resource_View $view
     */
    protected function _initRoutes()
    {
        $frontController = Zend_Controller_Front::getInstance();
        $route = new Zend_Controller_Router_Route(
                'home', // The URL, after the baseUrl, with no params.
                array(
                    'controller' => 'index', // The controller to point to.
                    'action'     => 'index'  // The action to point to, in said Controller.
                )
        );
        $frontController->getRouter()->addRoute('home', $route);
    }
}