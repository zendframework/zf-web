<?php
_('l_default_value');
_('l_object_description');
_('l_object_document');
_('l_object_tags');
_('l_object_title');
_('l_object_type');
_('l_object_publish_start');
_('l_object_publish_end');
_('l_object_create');
_('l_object_update');
_('l_file_description');
_('l_file_remove');
_('l_file_submit');
_('l_file_title');
_('l_file_upload');
_('l_page_body');
_('l_page_description');
_('l_page_remove');
_('l_page_submit');
_('l_page_title');
_('l_role_description');
_('l_role_name');
_('l_role_remove');
_('l_login');
_('l_log_in');
_('l_pass');

//custom fields
_('l_field1');
_('l_field2');
_('l_field_boolean');
_('l_field_boolean_name');
_('l_field_configuration');
_('l_field_date');
_('l_field_description');
_('l_field_description_translated');
_('l_field_dropdown');
_('l_dropdown_elements');
_('l_field_main_options');
_('l_field_maxlen');
_('l_field_mixlen');
_('l_field_name');
_('l_field_name_translated');
_('l_field_numbers');
_('l_field_remove');
_('l_field_required');
_('l_field_required_register');
_('l_field_shown_in_language');
_('l_field_show_on_listings');
_('l_field_show_to_staff_only');
_('l_field_submit');
_('l_field_text');
_('l_field_text_validation');
_('l_field_textarea');
_('l_field_type');
_('l_none');





//validate errors
_('stringLengthTooShort');
_('stringLengthTooLong');
_('notAlnum');
_('stringEmpty');
_('notAlpha');
_('notBetween');
_('notBetweenStrict');
_('dateNotYYYY-MM-DD');
_('dateInvalid');
_('dateFalseFormat');
_('notDigits');
_('emailAddressInvalid');
_('emailAddressInvalidHostname');
_('emailAddressInvalidMxRecord');
_('emailAddressDotAtom');
_('emailAddressQuotedString');
_('emailAddressInvalidLocalPart');

?>

