<?php
class IndexController extends Zend_Controller_Action
{
	function preDispatch(){
		parent::preDispatch();
	}

	function init(){
		parent::init();
	}

	function postDispatch(){
		parent::postDispatch();
	}

	function indexAction(){
        require_once 'Zend/Locale.php';
        require_once 'Zend/Translate.php';
        $config = Zend_Registry::get('config');
		$this->locale = new Zend_Locale($config->setup->defaultLocale);
		Zend_Registry::set('locale', $this->locale);
		Zend_Translate::setCache(Zend_Registry::get('cache'));
		Zend_Registry::set('Zend_Translate', new Zend_Translate('gettext', './Application/Locale/pl/default.mo', 'pl'));
	}
}
?>