<?php
_('o_document_updated');
_('o_file_added');
_('o_file_updated');
_('o_file_removed');
_('o_logged_in');
_('o_logged_out');
_('o_object_added');
_('o_object_removed');
_('o_page_added');
_('o_page_updated');
_('o_page_removed');
_('o_role_added');
_('o_role_updated');
_('o_role_removed');
_('o_field_added');
_('o_field_removed');
_('o_field_updated');


//errors
_('e_dont_touch_root');
_('e_file_not_found');
_('e_object_not_found');
_('e_page_not_found');
_('e_role_not_found');
_('e_field_not_found');
_('e_permission_too_low');

?>