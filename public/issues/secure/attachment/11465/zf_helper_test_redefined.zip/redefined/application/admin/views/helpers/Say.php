<?php
class MyZend_View_Helper_Say
{
    public function say()
    {
        return 'Say what?';
    }

}