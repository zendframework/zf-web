<?php
ini_set('display_errors', true);
error_reporting(E_ALL | E_STRICT);
$base = dirname(realpath(dirname(__FILE__)));
set_include_path(".:$base/library");

require_once 'Zend/Loader.php';
Zend_Loader::registerAutoload();

/**
 * Front controller
 */
$front = Zend_Controller_Front::getInstance();

/**
 * Where are our modules' controllers
 */
$front->addModuleDirectory($base . '/application');

$viewRenderer = Zend_Controller_Action_HelperBroker::getStaticHelper('viewRenderer');
$viewRenderer->setView(new Zend_View());
$viewRenderer->view->addHelperPath($base . '/application/admin/views/helpers', 'MyZend_View_Helper');

/**
 * Go go go!
 */
$front->dispatch();
